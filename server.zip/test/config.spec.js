describe('Environment Config Test', function() {

    var expect = require('chai').expect,
        should = require('chai').should(),
        config = require('../config/config');


    after(function(){
        process.env.NODE_ENV = 'test';
    });


    it('verify production config is initialized properly', function(){
        process.env.NODE_ENV = 'production';
        let activeEnv=config(process.env.NODE_ENV);
        should.exist(activeEnv.server);
        expect(activeEnv.server.JAVA_PORT).to.equal(3005);
    });

    it('verify development config is initialized properly', function(){
        process.env.NODE_ENV = 'development';
        let activeEnv=config(process.env.NODE_ENV);
        should.exist(activeEnv.server);
        expect(activeEnv.server.JAVA_PORT).to.equal(3006);
    });

    it('verify qa config is initialized properly', function(){
        process.env.NODE_ENV = 'qa';
        let activeEnv=config(process.env.NODE_ENV);
        should.exist(activeEnv.server);
        expect(activeEnv.server.JAVA_PORT).to.equal(3007);
    });

    it('verify default config is initialized properly', function(){
        process.env.NODE_ENV = '';
        let activeEnv=config(process.env.NODE_ENV);
        should.exist(activeEnv.server);
        expect(activeEnv.server.JAVA_PORT).to.equal(4444);
    });

});