describe('Environment Config Test', function() {

    var expect = require('chai').expect,
        should = require('chai').should(),
        errorHandler = require('../utils/error_handler');


    after(function(){
        process.env.NODE_ENV = 'test';
    });


    it('verify handleError method configured properly', function(){
        let errorResponse=errorHandler.handleError("test error",[],400,true,false);
        expect(errorResponse['status']).to.equal(400);
        expect(errorResponse['error']).to.equal(true);
        expect(errorResponse['success']).to.equal(false);
    });

    it('verify serverError method configured properly', function(){
        let errorResponse=errorHandler.serverError();
        expect(errorResponse['message']).to.equal('internal server error.');
        expect(errorResponse['status']).to.equal(500);
        expect(errorResponse['error']).to.equal(true);
        expect(errorResponse['success']).to.equal(false);
    });

    it('verify recordAlreadyExist method configured properly', function(){
        let errorResponse=errorHandler.recordAlreadyExist();
        expect(errorResponse['message']).to.equal('This record already exists..');
        expect(errorResponse['status']).to.equal(422);
        expect(errorResponse['error']).to.equal(true);
        expect(errorResponse['success']).to.equal(false);
    });


});