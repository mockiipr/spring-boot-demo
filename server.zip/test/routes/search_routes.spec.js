

let constants = require('../../utils/constant');
let chai = require('chai');
let nock = require('nock');
let assert = chai.assert;
let expect = chai.expect;
let http_mocks = require('node-mocks-http');
let should = require('should');

let SearchController = require('../../controllers/search_controller').SearchController;
let searchController = new SearchController();
let request = require('supertest');
let searchResponse = require('../../DB/search-table.json');
let express = require('express');
let app = express();
let config = require('../../config/config');
let  activeEnv = config(process.env.NODE_ENV);
let server_url = activeEnv.urls.JAVA_URL+':'+activeEnv.server.JAVA_PORT;
let url = 'http://localhost:7070';

// describe('Search Controller', () => {
//     it('Search Controller', async function(){
//         const res = await request(app)
//             .get(url + '/api/search');
//         expect(res.statusCode).to.equal(200);
//     });
// });

// function buildResponse() {
//     return http_mocks.createResponse({eventEmitter: require('events').EventEmitter})
// }
// describe('Search Controller', () => {
//     it('GET Search Results', function(done) {
//         var response = searchResponse;
//         var request  = http_mocks.createRequest({
//             method: 'GET',
//             url: `${url}/api/search`,
//         })
   
//         response.on('end', function() {
//             response._getData().should.equal('world');
//             done()
//         })

//         SearchController.search().handle(request, response);
//     });
// });

// describe('GET Search Results', () => {
//     beforeEach(() => {
//         nock(`${server_url}`)
//           .get('/api/search')
//           .reply(200, searchResponse);
//       });
  
//     it('Should return search results', () => {
//         return searchController.search()
//         .then(response => {
//             console.log(response);
//             expect(typeof response).to.equal('object');
//     });
//   });
// });

//   describe('GET Search Results', () => {
//     beforeEach(() => {
//         nock(`${activeEnv.urls.JAVA_URL}:${activeEnv.server.JAVA_PORT}`)
//         .get(`/api/associates`)
//         .reply(200, response);
//     });
  
//     it('Should return Associates', () => {
//          searchController.associates()
//           expect(typeof response).to.equal('object');
//           expect(response.name).to.equal('checkResponse')

//     });
//   });

describe("check search response", function () {
    beforeEach(() => {
        nock(`${url}`)
            .get(`/api/search`)
            .reply(200, searchResponse);
    });

    it("Search Results", function () {
        let search = searchController.search();
        return request(app)
        .get(url+'/api/search')
        .then(function(res){
            expect(res.statusCode).to.equal(403);
        });
    })

    it("Associates", function () {
        let associates = searchController.associates;
    })

    it("Frequent Searches", function () {
        let frequent_searches = searchController.frequent_searches();
    })

    it("Recent Searches", function () {
        let recent_searches = searchController.recent_searches();
    })

    it("Plans", function () {
        let plans = searchController.plans();
    })
})

