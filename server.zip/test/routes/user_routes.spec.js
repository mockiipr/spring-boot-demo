
// const nock = require('nock');
// const constants= require('../../utils/constant');
// let chai = require('chai');

// const expect = chai.expect;

// const {LoginController} = require('../../controllers/login_controller')
// let loginController = new LoginController();

// let config=require('../../config/config')
// const response ={name: 'checkResponse',status:()=>{
//     return {send:(v)=>{
//         return v;
//     }}
// }}
// let activeEnv=config(process.env.NODE_ENV);
// describe("check user login", function () {
//     beforeEach(() => {
//         nock(`${activeEnv.urls.JAVA_URL}:${activeEnv.server.JAVA_PORT}`)
//           .get(`/api/login/?id=${constants.TEST_USER_CREDENTIALS.id}&pass=${constants.TEST_USER_CREDENTIALS.pass}`)
//           .reply(200, response);
//       });
//     let req={query:{id:'1234',pass:'test'}};
//     it("login success pass", function (done) {
//          expect(response.name).to.equal('checkResponse');
//         done();
//     });
// })

