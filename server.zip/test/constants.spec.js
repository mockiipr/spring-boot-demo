let chai = require('chai');
const expect = chai.expect; 
describe('Constants Initialisation Test', function() {

    var should = require('chai').should(),
        constants = require('../utils/constant');


    it('verify constants were initialized properly', function(){
        should.exist(constants.TEST_USER_CREDENTIALS);
        should.exist(constants.SEARCH_DATA);
    });

    it('verify constants values were initialized properly', function(){
        should.exist(constants.TEST_USER_CREDENTIALS.id);
        should.exist(constants.TEST_USER_CREDENTIALS.pass);
        should.exist(constants.SEARCH_DATA.keyword);
        expect(constants.TEST_USER_CREDENTIALS.id).to.equal('testId');
        expect(constants.TEST_USER_CREDENTIALS.pass).to.equal('testPass');
    });

});