// 'use strict';
// const express= require('express');
// const LoginController = require('../controllers/login_controller').LoginController;
// const loginValidation=require('../validation/login_validations');
// const URL_ROUTES=require('../commons/routes');

// class LoginRouter {

//   constructor() {
//     this.routes = express.Router();
//     const loginController = new LoginController();
//     const ctrl = c => loginController[c].bind(loginController)();
//     this.routes.get(URL_ROUTES.LOGIN,loginValidation.validate('loginValidator'), ctrl('login'));
//     this.routes.post(URL_ROUTES.NEW_USER,loginValidation.validate('newUserValidator'),ctrl('newUser'));
//   }
//   getRoutes() {
//     return this.routes;
//   }

// }
// exports.LoginRouter = LoginRouter;
