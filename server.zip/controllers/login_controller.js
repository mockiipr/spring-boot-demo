// 'use strict';
// const http = require('http');
// let config=require('../config/config')
// let errorHandler=require('../utils/validation_error_handler')
// let env=process.env.NODE_ENV?process.env.NODE_ENV:'';
// let activeEnv=config(env);
// let server_url=activeEnv.urls.JAVA_URL+':'+activeEnv.server.JAVA_PORT;
// class LoginController {
// constructor() {}

//   login() {
//     return([
//       errorHandler.validationHandler,
//       function (req, res, next) {
//         http.get(`${server_url}/api/getPass/?id=${req.query.id}&pass=${req.query.pass}`, (resp) => {
//           let data = '';
//           resp.on('data', (chunk) => {
//             data += chunk;
//           });
//           resp.on('end', () => {
//             console.log(JSON.parse(data));
//             res.status(200).send({
//               "status": 200,
//               "statusText": "Success",
//               "message": "Call Successful!",
//               "id": JSON.parse(data).id,
//               "pass": JSON.parse(data).pass
//             });
//           });

//         }).on("error", (err) => {
//           console.log("Error: " + err.message);
//           res.status(400).send({
//             "status": 400,
//             "statusText": "Failed",
//             "message": "Java server not available.",
//           });
//         });
//       }
//     ]);

//   }

//   newUser() {
//    return ([
//       errorHandler.validationHandler,
//       function(req, res, next) {
//         res.status(200).send({
//           "status": 200,
//           "statusText": "Passed validation",
//           "sanitizedBody": req.body
//         })

//       }
//     ])
//   }

// }

// exports.LoginController = LoginController;