'use strict';

let http = require('http');
let config = require('../config/config')
let env = process.env.NODE_ENV ? process.env.NODE_ENV : '';
let activeEnv = config(env);
let server_url = activeEnv.urls.JAVA_URL + ':' + activeEnv.server.JAVA_PORT;

// Mock Data JSON Files
const search = require('../DB/search-table.json');
const recentSearches = require('../DB/recent-searches.json');
const associates = require('../DB/associates.json');
const frequentSearches = require('../DB/frequent_searches.json');
const plans = require('../DB/plans.json');

class SearchController {

  constructor() { }

  search() {

    let getSearch = function (req, res, next) {
      http.get(`${server_url}/search-api-here`, (response) => {
        let data = '';
        response.on('data', (chunk) => {
          data += chunk;
        });
        response.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.send(JSON.stringify(search, null, 3));
      });
    }

    return getSearch;
  }

  recent_searches() {

    let getRecentSearches = function (req, res, next) {
      http.get(`${server_url}/recent_searches-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.send(JSON.stringify(recentSearches, null, 3));
      });
    }
    return getRecentSearches;

  }

  associates() {

    let getAssociates =  function (req, res, next) {
      http.get(`${server_url}/associates-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.send(JSON.stringify(associates, null, 3));
      });
    }

    return getAssociates;

  }

  frequent_searches() {

    let getFrequentSearches = function (req, res, next) {
      http.get(`${server_url}/frequent_searches-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.send(JSON.stringify(frequentSearches, null, 3));
      });
    }
    return getFrequentSearches;

  }

  plans() {

    let getPlans = function (req, res, next) {
      http.get(`${server_url}/plans-api`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.send(JSON.stringify(plans, null, 3));
      });
    }

    return getPlans;

  }

}

exports.SearchController = SearchController;