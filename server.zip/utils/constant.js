module.exports = {
  TEST_USER_CREDENTIALS:{id:'testId',pass:'testPass'},
  SEARCH_DATA: {keyword: 'IRK102544'}
}