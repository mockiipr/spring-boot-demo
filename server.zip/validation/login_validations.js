// //This file is for validation
// const {body,query,check} = require('express-validator');
// const constant = require('../utils/constant');

// function loginValidator() {
//   return [
//     query('id').exists().isAlpha(),
//     query('pass').isAlphanumeric()
//   ];
// }

// function newUserValidator() {
//   return [
//     body('first_name').trim().isAlpha(),
//     body('last_name').trim().isAlpha(),
//     body('birth_date').trim().isDate({'format':'YYYY/MM/DD'}).withMessage('Should be a valid date in format YYYY/MM/DD'),
//     body('email').trim().isEmail().normalizeEmail(),
//     body('mobile_number').trim().isMobilePhone("en-IN", {'strictMode': true, }).withMessage('Must be an Indian number starting with +91')
//   ];
// }

// exports.validate =(method) =>{
//    switch(method){
//      case 'loginValidator':{
//        return loginValidator()
//      }
//      break;
//      case 'newUserValidator':{
//       return newUserValidator()
//     }
//     break;
//    }
// }