var endPointsUrl = (function () {
    return {
        urls: {
                get: 'getPass/?id=&pass=',
        },
    };

})();

module.exports = endPointsUrl;