module.exports = {
    /**
     * @method :- handleError
     * @handleError : It handles all the general errors... 
     */
    handleError: (message = 'error occured', response = [], status = 404, error = true, success = false) => {
        return {
            message,
            response,
            status,
            error,
            success
        }
    },

    /**
     * @method :- notFound
     * @notFound : It handles all the server related errors... 
     */
    serverError: (message = 'internal server error.', response = [], status = 500, error = true, success = false) => {
        return {
            message,
            response,
            status,
            error,
            success
        }
    },

    /**
     * @method :- recordAlreadyExist
     * @recordAlreadyExist : It handles all the error related to the already exist record errors... 
     */
    recordAlreadyExist: (message = 'This record already exists..', response = [], status = 422, error = true, success = false) => {
        return {
            message,
            response,
            status,
            error,
            success
        }
    },
}