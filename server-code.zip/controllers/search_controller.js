'use strict';

let http = require('http');
let config = require('../config/config')
let env = process.env.NODE_ENV
let activeEnv = config(env);
let server_url = activeEnv.urls.JAVA_URL + ':' + activeEnv.server.JAVA_PORT;
let errorHandler = '../utils/error_handler.js';

// Mock Data JSON Files
const search = require('../fs/search-table.json');
const recentSearches = require('../fs/recent-searches.json');
const associates = require('../fs/associates.json');
const frequentSearches = require('../fs/frequent_searches.json');
const plans = require('../fs/plans.json');

class SearchController {

  constructor() { }

  search() {
    errorHandler
    let getSearch = function (req, res, next) {
      http.get(`${server_url}/search-api-here`, (response) => {
        let data = '';
        response.on('data', (chunk) => {
          data += chunk;
        });
        response.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.status(500).send(JSON.stringify(search, null, 3));
      });
    }

    return getSearch;
  }

  recent_searches() {
    errorHandler
    let getRecentSearches = function (req, res, next) {
      http.get(`${server_url}/recent_searches-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.status(500).send(JSON.stringify(recentSearches, null, 3));
      });
    }
    return getRecentSearches;

  }

  associates() {
    errorHandler
    let getAssociates =  function (req, res, next) {
      http.get(`${server_url}/associates-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.status(500).send(JSON.stringify(associates, null, 3));
      });
    }

    return getAssociates;

  }

  frequent_searches() {
    errorHandler
    let getFrequentSearches = function (req, res, next) {
      http.get(`${server_url}/frequent_searches-api-here`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.status(500).send(JSON.stringify(frequentSearches, null, 3));
      });
    }
    return getFrequentSearches;

  }

  plans() {
    errorHandler
    let getPlans = function (req, res, next) {
      http.get(`${server_url}/plans-api`, (resp) => {
        let data = '';
        resp.on('data', (chunk) => {
          data += chunk;
        });
        resp.on('end', () => {
          res.header("Content-Type", 'application/json');
          res.status(200).send(data);
        });

      }).on("error", (err) => {
        // Mock Data on error
        res.header("Content-Type", 'application/json');
        res.status(500).send(JSON.stringify(plans, null, 3));
      });
    }

    return getPlans;

  }

}

exports.SearchController = SearchController;