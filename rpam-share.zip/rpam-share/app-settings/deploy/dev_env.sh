#!/bin/bash

# Export specific env values to be substituted in Kube templates
export env="dev"
export replicas="2"
export version="5"
