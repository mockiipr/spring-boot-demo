#!/bin/bash

# Export specific env values to be substituted in Kube templates
export env="prod"
export replicas="4"
export version="4"
