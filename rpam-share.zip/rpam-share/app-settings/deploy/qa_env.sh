#!/bin/bash

# Export specific env values to be substituted in Kube templates
export env="qa"
export replicas="3"
export version="4"
