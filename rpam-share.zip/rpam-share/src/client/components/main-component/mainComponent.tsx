import React from 'react';
import Logging from "client/services/client-logging";
import Grid from '@material-ui/core/Grid';
import Moment from 'react-moment';

class MainComponent extends React.Component {
    logging = new Logging();
    render() {
        this.logging.info('Dashboard render')
        return (
            <div>
                <Grid container spacing={3}>
                <Grid item md={6} sm={6} xs={6}>
                    <div className="welcome-text">Welcome back Alice!</div>
                </Grid>
                <Grid item md={6} sm={6} xs={6}>
                    <div className="todays-date text-right">
                    <Moment format="dddd, MMMM D">
                        {new Date()}
                    </Moment>
                    </div>
                </Grid>
                <Grid item md={6} sm={12} xs={12}>
                    <div className="Rectangle">
                        <div className="Input-text">
                            Inbox (TBD)
                        </div>
                    </div>
                    </Grid>
                    <Grid item md={6} sm={12} xs={12}>
                    <div className="Rectangle">
                        <div className="Input-text">
                            Reminders (TBD)
                        </div>
                    </div>
                    </Grid>
                    <Grid item md={12} sm={12} xs={12}>
                    <div className="Rectangle2">
                        <div className="Input-text">
                            Sources (TBD)
                        </div>
                    </div>
                    </Grid>
                </Grid>
            </div>
        )
    }
}

// const mapStateToProps = (state) => {
//     return {
//     };
// };
// const mapDispatchToProps = (state) => {
//     return {
//     };
// };
export default MainComponent
// connect(
//     mapStateToProps,
//     mapDispatchToProps
// )(MainComponent);