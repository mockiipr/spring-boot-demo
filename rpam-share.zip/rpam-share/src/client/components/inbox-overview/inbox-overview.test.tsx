import React from 'react';
import InboxOverview from './inbox-overview';
import { shallow, configure, mount } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";

configure({ adapter: new Adapter() });

describe('components --> InboxOverview', () => {
  it('renders header without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<InboxOverview />, div);
  });
  it('should have header', () => {
    const _wrapper = shallow(<InboxOverview />)
    expect(_wrapper.find('.header')).toHaveLength(1)
  })

});
