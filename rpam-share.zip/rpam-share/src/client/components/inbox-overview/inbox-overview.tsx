import React from 'react';
import './../main-component/mainComponent.scss';

const InboxOverview = () => (
    <div className="header">
        Hi there
    </div>
)

export default InboxOverview;