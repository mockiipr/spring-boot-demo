import React, { Component } from "react";
import './default-modal.scss';
import { isIE, isEdge } from "react-device-detect";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import classNames from "classnames";
import AddCircleOutlineOutlinedIcon from '@material-ui/icons/AddCircleOutlineOutlined';
import RemoveCircleOutlineOutlinedIcon from '@material-ui/icons/RemoveCircleOutlineOutlined';
import Icon from '@material-ui/core/Icon';
import {
  Chip,
  Grid,
  Button,
  Modal,
  Divider
} from '@material-ui/core';

interface SettingsModalProps {
  openModal: boolean;
  onSave: Function;
  onCancel: Function;
  settings: any
}
interface SettingsModalState {
  selectedValue: any,
  chekbox: boolean,
  settingsData: any,
  selectedCols: number,
}

class SettingsModal extends Component<SettingsModalProps, SettingsModalState> {
  constructor(props) {
    super(props);

    this.state = {
      selectedValue: null,
      chekbox: false,
      settingsData: this.props.settings,
      selectedCols: 0,
    };
  }
  componentDidMount() {
    let { settings } = this.props;
    const selectedCols = Object.keys(settings).filter((item) => {
      return settings[item] === true
    }).length;
    this.setState({ selectedCols });
  }
  handleChange = (event, value) => {
    this.setState({ selectedValue: value })
  }
  handleCancel = () => {
    this.props.onCancel();
  }
  handleMove = () => {
    //this.props.onChange(this.state.selectedValue);
  }
  handleChkboxChange = (event) => {
    this.setState({ chekbox: event.target.checked });
  };
  toggleSetting = (prop: any) => {
    console.log(prop);
    const { settingsData } = this.state;
    settingsData[prop] = !settingsData[prop];
    const deleteIds = Object.keys(settingsData).filter((item) => {
      return settingsData[item] === true
    });
    console.log(deleteIds);
    if (deleteIds.length <= 11)
      this.setState({
        settingsData: settingsData, selectedCols: deleteIds.length
      });
  }
  handleSave = () => {
    this.props.onSave(this.state.settingsData);
  }
  url = (prop: any) => {
    const { settingsData } = this.state;
    return settingsData[prop] == true ? 'client'
      : 'clientsss';
  }
  icon = (prop: any) => {
    const { settingsData } = this.state;
    return settingsData[prop] == true ?
      <img style={{ float: 'right' }} src={require('client/assets/images/remove_circle-24px.svg')} />
      : <img style={{ float: 'right' }} src={require('client/assets/images/add_circle-24px.svg')} />;
  }
  render() {
    const { openModal } = this.props;
    const { selectedValue, settingsData, selectedCols } = this.state;
    return (
      <div id="WorkItem-Modal" className="progress-modal-container">
        <Modal open={openModal} >
          <div className={classNames({
            "modal": true,
            "internet-explorer": isIE || isEdge
          })}>

            <div className="modal-text ">Edit search results view by ADD or REMOVE columns</div>

            <Grid className='popup-button-footer'>
              {/* <Button id="cancelButton" className="cancel-btn" onClick={this.handleCancel}>
                Cancel </Button> */}
              <Button id="moveButton"
                className={classNames('move-btn', {
                  //  "move-enabled": selectedValue != null,
                })} onClick={this.handleSave}>
                Yes</Button>
              <Button id="moveButton"
                className={classNames('move-btn', {
                  //  "move-enabled": selectedValue != null,
                })} onClick={this.handleSave}>
                No</Button>
            </Grid>
          </div>
        </Modal>
      </div>
    );
  }
}

export default SettingsModal;