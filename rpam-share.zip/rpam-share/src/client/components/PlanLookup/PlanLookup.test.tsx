import React from 'react';
import PlanLookup from './PlanLookup';
import { Provider } from 'react-redux';
import { shallow, configure, mount } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as ReactDOM from "react-dom";
import { BrowserRouter as Router } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import renderer from 'react-test-renderer';

configure({ adapter: new Adapter() });

const mockStore = configureStore([]);
describe('components -->  PlanLookup', () => {
  let store;
  let component;
  beforeEach(() => {
    store = mockStore({
      myState: 'sample text',
    });
    component = renderer.create(
      <Provider store={store}>
        <PlanLookup />
      </Provider>
    );
  });
  it('should render with given state from Redux store', () => {
    expect(component.toJSON()).toMatchSnapshot();
  });
  // it('renders PlanLookup without crashing', () => {
  //   const div = document.createElement('div');
  //   ReactDOM.render(<PlanLookup />, div);
  // });

  it('Should contain scss class plan-lookup-container', () => {
    const _wrapper = mount(<Provider store={store}>
      <PlanLookup />
    </Provider>);
    expect(_wrapper.find('.plan-lookup-container')).toHaveLength(1)
  })
});
