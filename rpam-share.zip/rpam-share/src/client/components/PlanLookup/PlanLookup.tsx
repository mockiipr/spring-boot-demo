import React, { Component } from 'react';
import ReactDOM from 'react-dom';
//import { withRouter } from "react-router";
import { getAssociateList, getSearchData } from "client/app-redux";
import { connect } from "react-redux";
import './PlanLookup.scss';
import { DataGrid, AssociateData } from "client/models"
import { DebounceInput } from 'react-debounce-input';
import {
    NativeSelect,
    Paper,
    Grid,
    Divider,
    FormControl,
    IconButton,
    Select,
    makeStyles,
    MenuItem,
    Theme,
    Button,
    Box, FormGroup, FormControlLabel, Checkbox, Popover
} from "@material-ui/core";
import { SearchPlanList, Advancedpopover, SearchBox, PlanDropdown } from 'client/components';
import Moment from 'react-moment';
const associateArray = [
    {
        "AssociateKey": "LGD",
        "firstName": "Caesare",
        "lastName": "Pettit",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "RUL",
        "firstName": "Lynnette",
        "lastName": "Boerger",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "BRIA",
        "firstName": "Elly",
        "lastName": "Kynaston",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "RJJ",
        "firstName": "Lynnette",
        "lastName": "Orozco",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "MRG",
        "firstName": "Hephaestus",
        "lastName": "Euphemia",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "DBS",
        "firstName": "Wilford",
        "lastName": "Dahl",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "LRRS",
        "firstName": "Del",
        "lastName": "Turov",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "JVF",
        "firstName": "Vasanti",
        "lastName": "Joleen",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "VXR",
        "firstName": "Upamanyu",
        "lastName": "Arabinda",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "JEAM",
        "firstName": "Thu",
        "lastName": "Demma",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "LSAM",
        "firstName": "Jackie",
        "lastName": "Thom",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "KERE",
        "firstName": "Gunaratna",
        "lastName": "Sommer",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "SRK",
        "firstName": "Teerth",
        "lastName": "Vijayabhas",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "WTC",
        "firstName": "Laurette",
        "lastName": "Kolb",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "ANEB",
        "firstName": "Ajinkya",
        "lastName": "Sharleen",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "JAMY",
        "firstName": "Vella",
        "lastName": "Holcombe",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    },
    {
        "AssociateKey": "STL",
        "firstName": "Prometheus",
        "lastName": "England",
        "teamManagerId": "",
        "roleId": "Client Coordinator"
    }
]

const associateData: Array<AssociateData> = [
    {
        "associateSuid": "1089",
        "cgInitials": "AAM",
        "activeToDate": null,
        "role": null,
        "roleTypeDesc": "Client Coordinator",
        "roleTypeSuid": "637",
        "selectedAssociate": null,
        "siteTypeSuid": null,
        "siteType": null,
        "specificSiteId": null,
        "allowedToMoveSource": true,
        "siteSpecific": false
    }
];

interface GridState {
    plan: any,
    associateData: any[],
    openPlan: boolean,
    dropdownValue: any,
    openPlanDropdown: boolean,
    openDropdown: boolean,
    openSearch: boolean,
    anchor: any,
    tags: any,
    checkedItems: any,
    selectedPlanVal: any
}
interface GridProps {
    getGridData?: any,
    inboxList?: { searchResults: DataGrid[], totalNumRecords: number };
    getAssociateData?: any,
    associateList?: any[];
}
class PlanLookup extends Component<GridProps, GridState>{
    state = {
        dropdownValue: '',
        checkedItems: new Map(),
        openSearch: false,
        openDropdown: false,
        openPlanDropdown: false,
        selectedPlanVal: 'All Plans',
        plan: 10,
        associateData: null,
        openPlan: false,
        anchor: null,
        tags: [],
    };

    handleChange = (event) => {
        // setAge(event.target.value);
        this.setState({ plan: event.target.value });
    }
    handleCheckboxChange = (e) => {

        const item = e.target.name;
        const isChecked = e.target.checked;

        this.setState(prevState => ({
            checkedItems: prevState.checkedItems.set(item, isChecked)
        }));

    };
    clearSelection = () => {
        const { checkedItems } = this.state;
        checkedItems.clear();
        this.setState({
            checkedItems
        });
    }
    handleClose = () => {
        this.setState({ openPlan: false, anchor: null });
    }

    handleOpen = (e) => {
        this.setState({ openPlan: true, anchor: e.currentTarget });
    }
    componentDidMount() {
        //   this.getGridData();
        this.props.getAssociateData();

        this.setState({ associateData: associateArray });
        document.addEventListener('click', this.handleClickOutside, true);
    }
    componentDidUpdate(prevProps) {
        // Typical usage (don't forget to compare props):
        if (this.props.inboxList !== prevProps.inboxList) {
            console.log(this.props.inboxList);
        }
    }
    componentWillUnmount() {
        document.removeEventListener('click', this.handleClickOutside, true);
    }
    getGridData() {
        let pageData = {
            startIndex: 1,
        };
        this.props.getGridData(pageData);
    }
    handleClickOutside = (event: any) => {
        const domNode = ReactDOM.findDOMNode(this);

        if (!domNode || !domNode.contains(event.target)) {
            this.setState({
                openSearch: false
            });
        }
    }
    filterFunction = (event: any) => {
        let input, filter, a, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        let div = document.getElementById("radio-groups");
        a = div.getElementsByTagName("label");
        for (let i = 0; i < a.length; i++) {
            txtValue = a[i].textContent || a[i].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                a[i].style.display = "";
            } else {
                a[i].style.display = "none";
            }
        }
    }
    dropdownToggle() {
        this.setState(prevState => ({
            openDropdown: !prevState.openDropdown
        }));
    }
    advPopupToggle() {
        this.setState(prevState => ({
            openPlan: !prevState.openPlan
        }));
    }

    onTagsChange = (event, values) => {
        this.setState({
            tags: values
        }, () => {
            // This will output an array of objects
            // given by Autocompelte options property.
            console.log(this.state.tags);
        });
    }
    openAdvPopover() {
        this.setState({});
    }
    
    onSelect = (param: any) => {
        this.setState({ openPlanDropdown: false, selectedPlanVal: param })
    }
    handleKeyUp = (e) => {
        this.setState({ openSearch: true });
        console.log(e);
    }

    handleSearch = (event) => {
        let searchObject = {
            searchText: event.target.value
        };
        if(searchObject.searchText.length > 2){
            this.props.getGridData(searchObject);
        }
    }
    render() {
        const { selectedPlanVal, openPlan, anchor, openSearch, checkedItems,         openDropdown, openPlanDropdown } = this.state;
        const { associateList } = this.props;
        //   console.log(associateList)
        let url: string = openDropdown ? 'color.png' : 'color_down.png';
        const id = openPlan ? 'simple-popover' : undefined;

        return (
            <div className="plan-lookup-container">
                <Paper>
                <div className='page-header'>
                        <Moment format="dddd, MMMM D">
                            {new Date()}
                        </Moment>
                    </div>
                    <form className='searchForm' noValidate autoComplete="off">
                        <FormControl >
                            <div>
                                <Grid container alignItems="center" className='table-header-bar'>
                                    <div className="dropdown">
                                        <Button onClick={() => this.dropdownToggle()} className="associate-dropdown">
                                            <span className="show-btn">All Associates</span>
                                            <span className={this.state.openDropdown ? 'down-arrow' : 'up-arrow'}></span>
                                            <img className='arrow-button' src={require('client/assets/images/' + url)} />
                                        </Button>
                                        {openDropdown && <div id="myDropdown" className="dropdown-content">
                                            <div>
                                                <input type="text" placeholder="Search Associates" id="myInput"
                                                    onKeyUp={(e) => this.filterFunction(e)}>
                                                </input>
                                                <div style={{ overflow: 'hidden' }}>
                                                    <FormControl component="fieldset" className='dropdown-formControl'>
                                                        <div className='action-buttons'>
                                                        <span onClick={this.clearSelection} className='clear-button'>Clear</span>
                                                            <span className='selection-count'>{checkedItems.size + ' selected'}</span>
                                                        </div>
                                                        <Divider variant="middle" orientation="horizontal" style={{ width: '100%' }} />
                                                        <div id="radio-groups">

                                                            <FormGroup>
                                                                {associateList && associateList.length > 0 && associateList.map((item) => (
                                                                    <FormControlLabel
                                                                        control={<Checkbox color='default' key={item.AssociateKey}
                                                                            checked={checkedItems.get(item.AssociateKey) || false}
                                                                            onChange={this.handleCheckboxChange}
                                                                            name={item.AssociateKey} />}
                                                                        label={item.AssociateKey + ' - ' + item.roleId}
                                                                    />
                                                                ))}
                                                                {/* <FormControlLabel
                                                                    control={<Checkbox color='default' checked={true} onChange={this.handleChkChange} name="gilad" />}
                                                                    label="AAM - Client Coordinator"
                                                                /><FormControlLabel
                                                                    control={<Checkbox color='default' checked={true} onChange={this.handleChkChange} name="gilad" />}
                                                                    label="AAM - Client Coordinator"
                                                                /><FormControlLabel
                                                                    control={<Checkbox color='default' checked={true} onChange={this.handleChkChange} name="gilad" />}
                                                                    label="AAM - Client Coordinator"
                                                                /><FormControlLabel
                                                                    control={<Checkbox color='default' checked={true} onChange={this.handleChkChange} name="gilad" />}
                                                                    label="AAM - Client Coordinator"
                                                                />
                                                                <FormControlLabel
                                                                    control={<Checkbox checked={false} onChange={this.handleChkChange} name="jason" />}
                                                                    label="AAVM - Client Coordinator"
                                                                />
                                                                <FormControlLabel
                                                                    control={<Checkbox checked={false} onChange={this.handleChkChange} name="antoine" />}
                                                                    label="AXAM - Client Coordinator"
                                                                /> */}
                                                            </FormGroup>
                                                        </div>
                                                        <Divider variant="middle" orientation="horizontal" style={{ width: '100%' }} />
                                                        <Grid className='dropdown-button-footer'>
                                                            <Button id="cancelButton" className="cancel-button" onClick={() => { this.dropdownToggle() }}>
                                                                Cancel </Button>
                                                            <Button id="okButton" type="submit" className="ok-button" onClick={(e) => { this.dropdownToggle() }}>
                                                                Ok</Button>
                                                        </Grid>
                                                    </FormControl>
                                                </div>
                                            </div>
                                        </div>}
                                    </div>
                                </Grid>
                            </div>
                        </FormControl>
                        <FormControl>
                            <div >
                                <Button onClick={() => this.setState(prevState => ({
                                    openPlanDropdown: !prevState.openPlanDropdown
                                }))} className="plan-dropdown">
                                   <span className="show-btn">{selectedPlanVal}</span>
                                    <span className={this.state.openPlanDropdown ? 'down-arrow' : 'up-arrow'}></span>
                                    <img className='arrow-button' src={require('client/assets/images/' + url)} />
                                </Button>
                                {openPlanDropdown && <PlanDropdown selectedValue={selectedPlanVal} onSelect={this.onSelect} />}
                            </div>
                        </FormControl>

                        <div className="search-dropdown">
                            <DebounceInput id="Search" name="Search" type="search"
                                minLength={3}
                                debounceTimeout={1200}
                                onChange = {e => this.handleSearch(e)}
                                placeholder="Search by Plan Name, Plan id or Tax ID" />
                            {openSearch && <div id="searchContent" className="search-content">
                                <SearchBox searchKey='' openSearch={openSearch} />
                            </div>}
                        </div>
                        <div style={{ display: 'inline-block' }}>
                            <Button aria-describedby={id} onClick={() => this.advPopupToggle()} className="advanced-button">
                                <img className='arrow-button' src={require('client/assets/images/group-2.svg')} />
                                <span className="show-btn">Advanced</span>
                            </Button>
                            {openPlan &&
                                <div>
                                    <Advancedpopover id={id} anchorEl={anchor} openModal={openPlan} close={this.handleClose} />
                                </div>
                            }
                        </div>

                        <Button onClick={() => { }} className="history-button">
                            <img className='arrow-button' src={require('client/assets/images/history-24-px.svg')} />
                        </Button>
                    </form>
                    <SearchPlanList />
                </Paper>
            </div >)
    }
}

const mapStateToProps = (state: any) => {
    return {
        search: state.search,
        associateList: state.associateList
    };
};
const mapDispatchToProps = (dispatch) => {
    return {
        getGridData: param => dispatch(getSearchData(param)),
        getAssociateData: param => dispatch(getAssociateList(param))
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(PlanLookup);
//export default Header;