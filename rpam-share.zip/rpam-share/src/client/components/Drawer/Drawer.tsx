import React, { Component, Fragment } from "react";
import { Theme, withStyles } from "@material-ui/core/styles";
import MenuIcon from "@material-ui/icons/Menu";
import { GlobalSearchBar } from "client/components";
import ClearIcon from '@material-ui/icons/Clear';
import './Drawer.scss';
import { Link } from "react-router-dom";
import classNames from "classnames";
import { GET_STARTED_PAGE_URI } from "client/constant";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { RouteComponentProps, withRouter } from "react-router";
import Tooltip from '@material-ui/core/Tooltip';
import MediaQuery from 'react-responsive';
import {
  Drawer,
  AppBar,
  List,
  Toolbar,
  Divider,
  IconButton,
  ListItem,
  Typography,
  ListItemText,
  ListItemIcon,
  Popover,
  Grid,
  Button
} from "@material-ui/core"
import {
  HOME_PAGE_URI,
  SOURCES_PAGE_URI,
  ALL_PLAN_SEARCH_PAGE_URI,
  IMAGING_BOX_PAGE_URI,
  REPORTS_PAGE_URI,
  REMINDERS_PAGE_URI,
  TOOLS_PAGE_URI,
  WORKITEMS_PAGE_URI,
  GET_WORK_PAGE_URI
} from "client/constant";

const styles = (theme: Theme) => ({
  root: {
    display: "flex"
  },
  appBar: {
    backgroundColor: "white",
    borderBottom: 'solid 1px #98aeb9',
    boxShadow: 'none',
    color: "black",
    zIndex: 9999
  },
  subtitle: {
    display: 'flex',
  },
  logo: {
    height: 33,
    padding: '15px 15px',
    cursor: 'pointer',
  },
  rpam: {
    marginLeft: theme.spacing(1),
    marginTop: theme.spacing(1),
  },
  refresh: {
    width: 30,
    height: 30,
    padding: '10px 10px'
  },
  menu: {
    fontSize: "1rem",
    fontFamily: "Roboto",
    color: "#333333",
    lineHeight: 1.5,
    letterSpacing: "0.00938em",
    height: "56px",
    padding: "16px 16px 16px 20px"

  },
  smallMenu: {
    height: "56px",
    padding: "16px 25px 16px 25px"

  },
  menuIcon: {
    fontSize: "27px",
    height: "30px",
  },
  menuList: {
    paddingTop: "73px"
  },
  selectedLink: {
    color: "#009adf"
  },
  hide: {
    display: "none"
  },
  drawer: {
    width: "100%",
    flexShrink: 0
  },
  drawerPaper: {
    height: "100%",
    width: "250px",
    backgroundColor: "#d5e1e6",
    boxShadow: "3px 4px 10px 0 rgba(0, 0, 0, 0.33)"
  },
  drawerPaperDesktop: {
    zIndex: 1,
    height: "100%",
    width: "77px",
    overflow: "hidden",
    background: "linear-gradient(to bottom, #d5e1e6 520px, rgba(129, 153, 177, 0.3) 0%)",
    borderRight: 'none'
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3)
  },
  toolbar: {
    justifyContent: "space-between"
  }
});

const LightTooltip = withStyles((theme: Theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 15,
  },
  arrow: {
    color: theme.palette.common.white,
  }
}))(Tooltip);

const menuItems: { text: string; link: string; icon: string; }[] = [
  { text: "Home", link: HOME_PAGE_URI, icon: 'home' },
  { text: "All Plans", link: ALL_PLAN_SEARCH_PAGE_URI, icon: 'all_plans' },
  { text: "Reminders", link: REMINDERS_PAGE_URI, icon: 'reminders' },
  { text: "Sources", link: SOURCES_PAGE_URI, icon: 'all_sources' },
  { text: "Imaging Box", link: IMAGING_BOX_PAGE_URI, icon: 'img_inbox' },
  { text: "Get Work", link: GET_WORK_PAGE_URI, icon: 'get_work' },
  { text: "Work Items", link: WORKITEMS_PAGE_URI, icon: 'work_items' },
  { text: "Reports", link: REPORTS_PAGE_URI, icon: 'reports' },
  { text: "Tools", link: TOOLS_PAGE_URI, icon: 'admin_tools' },
];

interface MobileNavbarProps extends RouteComponentProps {
  classes: any;
  theme: any;
  dispatch: Dispatch;
}

interface MobileNavbarState {
  open: boolean;
  selectedLink: string;
  tabletScreen: any;
  setAnchorEl: any;
  showSearchBar: boolean;
}

class MobileNavbar extends Component<MobileNavbarProps, MobileNavbarState> {
  state = {
    open: false,
    selectedLink: "",
    tabletScreen: 1024,
    setAnchorEl: null,
    showSearchBar: false,  
  };

  componentDidMount() {
    const { pathname } = this.props.location;
    this.setSelectedLink(pathname);
  }

  componentDidUpdate(prevProps: MobileNavbarProps) {
    const { pathname } = this.props.location;
    if (this.props.location.pathname !== prevProps.location.pathname) {
      this.setSelectedLink(pathname);
    }
  }

  setSelectedLink(link: string) {
    switch (link) {
      case GET_STARTED_PAGE_URI:
        this.setState({ selectedLink: GET_STARTED_PAGE_URI });
        break;

      default:
        this.setState({ selectedLink: "" });
        break;
    }
  }

  toggleDrawer = () => {
    const { open } = this.state;
    this.setState({ open: !open });
  };
  onClick = () => {
    this.setState({ open: false });
  }
  onShowSearchBar(e: any) {
    //   e.stopPropagation();
    this.setState({ showSearchBar: true });
  }
  onHideSearchBar = () => {
    this.setState({ showSearchBar: false });
  }
  onLinkClick = (link: string) => {
    const { dispatch } = this.props;
    // let history = useHistory();
    // history.push("/home");
    //   dispatch(push(link));
    this.setState({ open: false });
  };
  handleClose = (e) => {
    this.setState({ setAnchorEl: null });
  };
  handleClick = (e) => {
    this.setState({ setAnchorEl: e.currentTarget });
  };
  render() {
    const { classes } = this.props;
    const { open, selectedLink, setAnchorEl, showSearchBar } = this.state;
    const opens = Boolean(setAnchorEl);
    const id = opens ? 'simple-popover' : undefined;
    return (
      <div className={classes.root}>
        <AppBar position="fixed" className={classes.appBar}>
          <Toolbar className={classes.toolbar}>
            <MediaQuery maxWidth={1024}>
              <IconButton
                color="inherit"
                aria-label="open drawer"
                onClick={this.toggleDrawer}
                edge="start"
                className={classNames(classes.menuButton)}
                id="hamburger-icon-button"
              >
                {this.state.open ?
                  <ClearIcon titleAccess='Menu' /> :
                  <MenuIcon titleAccess='Menu' />
                }
                <span style={{ height: '18px', fontSize: '18px' }}></span>
              </IconButton>
            </MediaQuery>
            <div className="mr-auto">
              <img className={classes.logo} alt="" src={require('client/assets/images/rpam_logo_banner.png')} />
            </div>
            <Typography variant="subtitle2" className={classes.subtitle} >
            <img onClick={(e) => this.onShowSearchBar(e)} className={classes.logo} alt="" src={require('client/assets/images/search-24-px-2.svg')} />
              {/* <Divider orientation="vertical" flexItem /> */}
              <a href="#" className="alert-icon">
                <span>
                  <img className={classes.logo} alt="" src={require('client/assets/images/notifications-24px.svg')} />
                </span>
                <span className="badge">3</span>
              </a>
              <div className='profile-initial' onClick={this.handleClick}>
                <span>AV</span>
              </div>
              <img className='profile-dropdown' alt="" src={require('client/assets/images/color.svg')} />
              <div>
                <Popover
                  className='popover-profile'
                  id={id}
                  open={opens}
                  anchorEl={setAnchorEl}
                  onClose={this.handleClose}
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center',
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 180,
                  }}>
                  <div className='popover-content profile-name'>Alice Velaskes</div>
                  <div className='popover-content'>Edit Profile</div>
                  <div className='popover-content'>View Settings</div>
                  {/* <Divider orientation="vertical" flexItem /> */}
                  <Divider variant="fullWidth" orientation="horizontal" style={{ width: '100%' }} />
                  <Grid className='popover-footer'>
                    <Button id="okButton" type="submit" className="ok-button" onClick={(e) => { }}>
                      LOG OUT</Button>
                  </Grid>
                </Popover>
              </div>
            </Typography>
          </Toolbar>
        </AppBar>
        {/* Menu Drawer Tablet and Mobile Screens */}
        <MediaQuery maxWidth={1024}>
          <Drawer
            className={classNames(classes.drawer)}
            anchor="left"
            classes={{paper: classes.drawerPaper}}
            open={open}
          >
            <div />
            <List className={classes.menuList}>
              {menuItems.map(item => (
                <Fragment key={item.text}>
                  <ListItem style={{ textTransform: 'uppercase' }} button component={Link} onClick={() => this.onClick()} to={item.link} className={classes.menu}>
                    <ListItemIcon>
                    {item.icon == 'img_inbox' ? 
                            <div className="notification-mobile">
                              <span>5</span>
                            </div> 
                            : null}
                      <img className={classes.menuIcon} alt=""
                        src={window.location.hash.slice(1) === item.link ?
                          require('client/assets/navigation-icons/' + item.icon + '-24px-selected.svg') :
                          require('client/assets/navigation-icons/' + item.icon + '-24px.svg')} />
                    </ListItemIcon>
                    <ListItemText primary={item.text} />
                  </ListItem>
                </Fragment>
              ))}
            </List>
          </Drawer>
        </MediaQuery>
        {/* Menu Drawer Desktop and Laptop Screens */}
        <MediaQuery minWidth={1025}>
          <Drawer
            variant="permanent"
            className={classNames(classes.drawer)}
            anchor="left"
            classes={{ paper: classes.drawerPaperDesktop }}
            open={true}
          >
            <div />
            <List className={classes.menuList}>
              {menuItems.map(item => (
                <Fragment key={item.text}>
                  <LightTooltip title={item.text} placement="right" arrow>
                    <ListItem button component={Link} to={item.link} className={classes.smallMenu}>
                      <ListItemIcon>
                      {item.icon == 'img_inbox' ? 
                            <div className="notification">
                              <span>5</span>
                            </div> 
                            : null}
                        <img className={classes.menuIcon} alt=""
                          src={window.location.hash.slice(1) === item.link ?
                            require('client/assets/navigation-icons/' + item.icon + '-24px-selected.svg') :
                            require('client/assets/navigation-icons/' + item.icon + '-24px.svg')} />
                       
                      </ListItemIcon>
                    </ListItem>
                  </LightTooltip>
                </Fragment>
              ))}
            </List>
          </Drawer>
        </MediaQuery>
        <GlobalSearchBar
          id='GlobalSearch'
          openModal={showSearchBar}
          close={() => this.onHideSearchBar()}
          onBackdropClick={this.onHideSearchBar}
        />
      </div>
          );
  }
}

export default withRouter(
  connect()(withStyles(styles, { withTheme: true })(MobileNavbar))
);