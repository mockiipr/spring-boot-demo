import React from "react";
import { isIE, isEdge } from "react-device-detect";
import "./SearchPlanList.scss";
import { DataGrid, AssociateData } from "client/models";
import Logging from "client/services/client-logging";
//import { getAssociateList, getImagingInboxData } from "client/app-redux";
import { connect } from "react-redux";
//import { css } from "@emotion/core";
import {
    Table,
    TableBody,
    TableHead,
    Button,
    TableRow,
    TableCell,
    TableSortLabel,
    TablePagination,
    Snackbar,
    Tooltip,
    Paper,
    Grid,
    Divider,
    FormControl,
    IconButton
} from "@material-ui/core";
import Pagination from '@material-ui/lab/Pagination';
import { SettingsModal } from "client/components";
import {
    Order,
    ascendingOrder,
    descendingOrder,
    stableSort,
    getSorting
} from "client/services/Utils";
import classNames from "classnames";

const initSettings = {
    planName: true,
    planId: true,
    taxId: true,
    planStatus: true,
    dealerName: true
};

const headCells: HeadCell[] = [
    { id: 'planName', numeric: false, label: 'Plan Name', sortable: true },
    { id: 'planId', numeric: false, label: 'Plan Id', sortable: true },
    { id: 'taxId', numeric: false, label: 'Tax Id', sortable: true },
    { id: 'planStatus', numeric: false, label: 'Plan Status', sortable: true },
    { id: 'dealerName', numeric: false, label: 'Dealer Name', sortable: true },
    { id: 'dealerRepName', numeric: false, label: 'Dealer Representative Name', sortable: true },
    { id: 'TPAName', numeric: false, label: 'TPA Name', sortable: true },
    { id: 'tpaAddress', numeric: false, label: 'TPA  Address', sortable: true },
    { id: 'tpaEmailAddress', numeric: false, label: 'TPA Email Address', sortable: true },
    { id: 'tpaPhNumber', numeric: false, label: 'TPA Phone Number', sortable: true },
    { id: 'tpaTaxID', numeric: false, label: 'TPA Tax ID', sortable: true },
    { id: 'Notes', numeric: false, label: 'Notes', sortable: true },
];
interface DataGridProps {
    getGridData?: any
    searchList?: any;
    associateList?: Array<AssociateData>;
}

interface DataGridState {
    showSnackbar: boolean;
    order: Order;
    orderBy: keyof DataGrid;
    page: number,
    rowsPerPage: number,
    showSettingsPopup: boolean,
    openDropdown: boolean,
    settingsData: any,
    showLoader: boolean,
    userName: string,
    apiError: boolean
}

interface HeadCell {
    id: keyof DataGrid;
    label: string;
    numeric: boolean;
    sortable: boolean;
}
const data: DataGrid[] = [
    {
        appianTaskId: 268437382,
        dateTime: "",
        assignee: 'Richard Oliver MD 401K Plan',
        indexedBy: {
            "planIdNamePair": [
                {
                    "planId": "BRK104014",
                    "planName": "Closed"
                }
            ]
        },
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        TPAName: "S TYpe 34567",
        subjectLine: "TPA Free Payments",
        planStatus: "Plan Status"
    },
    {
        appianTaskId: 268437382,
        dateTime: "",
        assignee: 'Richard Oliver MD 401K ',
        indexedBy: {
            "planIdNamePair": [
                {
                    "planId": "BRK104014",
                    "planName": "Not Accepted"
                }
            ]
        },
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        TPAName: "S TYpe 34567",
        subjectLine: "TPA Free Payments",
        planStatus: "Plan Status"
    },
    {
        appianTaskId: 268437382,
        dateTime: "",
        assignee: 'Another Richard Oliver MD ',
        indexedBy: {
            "planIdNamePair": [
                {
                    "planId": "BRK104014",
                    "planName": "Pending Approval"
                }
            ]
        },
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        TPAName: "S TYpe 34567",
        subjectLine: "TPA Free Payments",
        planStatus: "Plan Status",
    }]


const dateTimeKey: keyof DataGrid = "dateTime";

class TableGrid extends React.Component<DataGridProps, DataGridState> {

    constructor(props) {
        super(props);

        this.state = {
            showSnackbar: false,
            settingsData: initSettings,
            order: descendingOrder,
            orderBy: dateTimeKey,
            page: 0,
            rowsPerPage: 10,
            openDropdown: false,
            showSettingsPopup: false,
            showLoader: false,
            userName: window['currentLoggedInUserName'],
            apiError: false
        };
    }

    logging = new Logging();


    componentDidUpdate(prevProps) {
        // Typical usage (don't forget to compare props):
        if (this.props.searchList !== prevProps.searchList) {
            this.setState({ showLoader: false });
        }
    }

    getGridData() {
        let pageData = {
            startIndex: 1,
            endIndex: this.state.rowsPerPage || 10,
            assignee: this.state.userName || '',
        };
        this.props.getGridData(pageData);
    }
    onColumnSort(headCell: HeadCell) {
        const { order, orderBy } = this.state;
        const isAsc = orderBy === headCell.id && order === ascendingOrder;
        this.setState({
            order: isAsc ? descendingOrder : ascendingOrder,
            orderBy: headCell.id
        })
    }

    handleChangePage = (event: any, newPage: number) => {
        this.logging.info('Page change called');
        this.setState({ page: newPage })
        //  this.callAPIOnPaginate(newPage, this.state.rowsPerPage);
    }
    handleChangeRowsPerPage = (event: any) => {
        this.logging.info('Rows per page changed to ' + event.target.value);
        this.setState({ page: 0, rowsPerPage: event.target.value })
        //   this.callAPIOnPaginate(0, event.target.value);
    }
    onPopupOpenClick(e: any) {
        e.stopPropagation();
        this.setState({ showSettingsPopup: true });
    }
    onPopupClose() {
        this.setState({ showSettingsPopup: false });
    }
    onSave = (param: any) => {
        this.setState({ showSettingsPopup: false, settingsData: param });
    }

    render() {
        const { searchList, associateList } = this.props;
        const { page, order, orderBy, settingsData,
            rowsPerPage, showSettingsPopup, openDropdown } = this.state;
        this.logging.info('Search Grid render called');
        return (
            <React.Fragment>
            {searchList ?
            <div className="data-table-component" id="TableGrid">
                <div className='data-table-wrapper' id="TableGrid-wrapper">
                    <Paper>
                        <div>
                            {/* {this.state.showLoader == false && <PulseLoader size={20} css={loader} color={"#3f51b5"} loading={true} />} */}
                            <Grid container alignItems="center" className='table-header-bar'>
                                <div className="results-length">
                                    {searchList.value.Value.length} Results
                                </div>
                                <div className="dropdown">
                                    <Button onClick={() => { }} className="close-button">
                                        <img className='arrow-button' src={require('client/assets/images/export_as_xl_24px.png')} />
                                    </Button>
                                    <Button onClick={(e) => this.onPopupOpenClick(e)} className="setting-button">
                                        <img className='arrow-button' src={require('client/assets/images/baseline_settings_black_24px.png')} />
                                    </Button>
                                </div>
                            </Grid>
                        </div>
                        {/* {this.state.showLoader == false && <Loading />} */}
                        <Table className="table" id="TableGrid-component">
                            <TableHead className="table-head" id="TableHead-TableGrid-component">
                                <TableRow className="header-row MuiPaper-root MuiPaper-elevation1">
                                    {headCells.map(headCell => (
                                        settingsData[headCell.id] == true && <TableCell key={headCell.id} className={classNames({
                                            "header-cell": true,
                                            "dateUpload": headCell.id === "planId",
                                            //  "description": headCell.id === "description"
                                        })} sortDirection={orderBy === headCell.id ? order : false}>
                                            <TableSortLabel
                                                active={headCell.id === orderBy}
                                                direction={headCell.id === orderBy ? order : ascendingOrder}
                                                hideSortIcon={!headCell.sortable}
                                                onClick={() => {
                                                    if (headCell.sortable) {
                                                        this.onColumnSort(headCell)
                                                    }
                                                }} >
                                                {headCell.label}
                                            </TableSortLabel>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody className="table-body">
                                {searchList && searchList.value && stableSort(searchList.value.Value, getSorting<any>(order, orderBy))
                                    .map((dataItem, index) => (
                                        <TableRow key={index} className={classNames({
                                            "body-row": true
                                        })} onClick={() => { }}>
                                            <TableCell className={classNames({
                                                "body-cell": true,
                                                "status": true,
                                            })}>
                                                <div className="status-date">
                                                    <div className="status">{dataItem.externalId}</div>
                                                </div>
                                            </TableCell>
                                            <TableCell
                                                // className="body-cell submitted"
                                                className={classNames({
                                                    "body-cell dateUpload": true
                                                })}>
                                                <div>{dataItem.id}</div>
                                            </TableCell>
                                            {settingsData.taxId == true && <TableCell className={classNames({
                                                "body-cell": true,
                                                "status": false,
                                            })}>
                                                <div >
                                                    <div >{dataItem.externalId}</div>
                                                </div>
                                            </TableCell>}
                                            {settingsData.planStatus == true && <TableCell className="body-cell">
                                                <div className={classNames({ "panel": true })}>
                                                    <div>
                                                        {dataItem.id}
                                                    </div>
                                                </div>
                                            </TableCell>}
                                            {settingsData.dealerName == true && <TableCell className="body-cell username">
                                                <Tooltip placement='bottom' title={dataItem.dealerName}>
                                                    <div className="text-wrap">{dataItem.dealerName}</div>
                                                </Tooltip>
                                            </TableCell>}
                                            {settingsData.dealerRepName == true && <TableCell className="body-cell username">
                                                <Tooltip placement='bottom' title={dataItem.repName}>
                                                    <div className="text-wrap">{dataItem.repName}</div>
                                                </Tooltip>
                                            </TableCell>}
                                            {settingsData.TPAName == true && <TableCell className="body-cell username">{dataItem.tpaName}</TableCell>}
                                            {settingsData.tpaEmailAddress == true && <TableCell className="body-cell subject">
                                                <div className="text-wrap">{dataItem.tpaName}</div>
                                            </TableCell>}

                                            {/*
                                                { id: 'tpaAddress', numeric: false, label: 'TPA  Address', sortable: true },
                                                { id: 'tpaPhNumber', numeric: false, label: 'TPA Phone Number', sortable: true },
                                                { id: 'tpaTaxID', numeric: false, label: 'TPA Tax ID', sortable: true },
                                                { id: 'Notes', numeric: false, label: 'Notes', sortable: true }, */}

                                            {settingsData.tpaAddress == true && <TableCell className="body-cell subject">
                                                <div className="text-wrap">{dataItem.dealerName}</div>
                                            </TableCell>}
                                            {settingsData.tpaPhNumber == true && <TableCell className="body-cell subject">
                                                <div className="text-wrap">{dataItem.dealerName}</div>
                                            </TableCell>}
                                            {settingsData.tpaTaxID == true && <TableCell className="body-cell subject">
                                                <div className="text-wrap">{dataItem.dealerName}</div>
                                            </TableCell>}
                                            {settingsData.Notes == true && <TableCell className="body-cell subject">
                                                <div className="text-wrap">{dataItem.dealerName}</div>
                                            </TableCell>}
                                        </TableRow>
                                    ))}
                            </TableBody>
                        </Table>
                        <TablePagination className={classNames({
                            "edge-right-align": isIE || isEdge
                        })} rowsPerPageOptions={[5, 10, 15, 20]}
                            component="table"
                            style={{ display: "flex", flexDirection: 'row-reverse' }}
                            count={searchList.value.Value.length}
                            colSpan={3}
                            // labelDisplayedRows={() => {
                            //     return `${page}-${Math.floor(1 / rowsPerPage)}`;
                            // }}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onChangePage={this.handleChangePage}
                            onChangeRowsPerPage={this.handleChangeRowsPerPage} />
                    </Paper>
                </div>
                {showSettingsPopup && (
                    <SettingsModal
                        openModal={showSettingsPopup}
                        onCancel={() => this.onPopupClose()}
                        onSave={this.onSave}
                        settings={settingsData}
                    />
                )}
            </div> : null}
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        searchList: state.search,
        associateList: state.associateList
    };
};
const mapDispatchToProps = (dispatch) => {
    return {
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(TableGrid);