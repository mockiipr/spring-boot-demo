import React from 'react';
import ReminderOverview from './reminder-overview';
import * as ReactDOM from "react-dom";
import Adapter from "enzyme-adapter-react-16";
import { shallow, configure, mount } from "enzyme";
configure({ adapter: new Adapter() });

describe('components --> ReminderOverview', () => {
  it('renders header without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<ReminderOverview />, div);
  });
  it('should have classes', () => {
    const _wrapper = shallow(<ReminderOverview />)
    expect(_wrapper.find('.table-container')).toHaveLength(1)
    expect(_wrapper.find('.table-head')).toHaveLength(1)
  })
});
