import React from "react";
import "./table.scss";
import { Table, TableBody, TableHead, TableRow, TableCell, TablePagination, Paper } from "@material-ui/core";

import Logging from "client/services/client-logging";

const columns = [
    { id: 'name', label: 'Name', minWidth: 170 },
    { id: 'code', label: 'Code', minWidth: 100 },
    {
        id: 'population',
        label: 'Profit(In Millions)',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    },
    {
        id: 'size',
        label: 'Size\u00a0(km\u00b2)',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    },
    {
        id: 'density',
        label: 'Density',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toFixed(2),
    },
];
const rows = [
    createData('A&R Enterprises LLC 401k Plan', 'IN', 1324171354, 3287263),
    createData('China', 'CN', 1403500365, 9596961),
    createData('A&R Enterprises LLC', 'IT', 60483973, 301340),
    createData('United States', 'US', 327167434, 9833520),
    createData('A&R Enterprises LLC 401k Plan', 'CA', 37602103, 9984670),
    createData('Australia', 'AU', 25475400, 7692024),
    createData('Germany', 'DE', 83019200, 357578),
    createData('Ireland', 'IE', 4857000, 70273),
    createData('Conger 401 K plan', 'MX', 126577691, 1972550),
    createData('Japan', 'JP', 126317000, 377973),
    createData('Conger 501 K plan', 'FR', 67022000, 640679),
    createData('A&R Enterprises LLC 401k Plan', 'CA', 37602103, 9984670),
    createData('A&R Enterprises LLC', 'AU', 25475400, 7692024),
    createData('Conger 401K plan', 'MX', 126577691, 1972550),
    createData('A&R Enterprises LLC', 'JP', 126317000, 377973),
    createData('A&R Enterprises LLC 401k Plan', 'FR', 67022000, 640679),
    createData('United Kingdom', 'GB', 67545757, 242495)
];
function createData(name, code, population, size) {
    const density = population / size;
    return { name, code, population, size, density };
}

interface TableState {
    showPopup: boolean;
    page: number;
    rowsPerPage: number;
}

class DataTable extends React.Component<{}, TableState> {
    state = {
        showPopup: false,
        page: 0,
        rowsPerPage: 5,
    };
    logging = new Logging();

    handleChangePage = (event, newPage) => {
        this.setState({ page: newPage })
    }

    handleChangeRowsPerPage = (event) => {
        this.setState({ page: 0, rowsPerPage: event.target.value })
    }

    render() {
        let { page, rowsPerPage } = this.state;
        this.logging.info('Table render');
        return (
            <div className="table-component">
                <div className='table-wrapper'>
                    <Paper>
                        <Table stickyHeader aria-label="sticky table" className="table">
                            <TableHead className="table-head">
                                <TableRow>
                                    {columns.map((column) => (
                                        <TableCell
                                            key={column.id}
                                            align={'left'}
                                            style={{ minWidth: column.minWidth }} >
                                            {column.label}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody className="table-body">
                                {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                                    return (
                                        <TableRow className="body-row" hover role="checkbox" tabIndex={-1} key={row.code}>
                                            {columns.map((column) => {
                                                const value = row[column.id];
                                                return (
                                                    <TableCell className="body-cell" key={column.id}>
                                                        {column.format && typeof value === 'number' ? column.format(value) : value}
                                                    </TableCell>
                                                );
                                            })}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25, 100]}
                            component="table"
                            count={rows.length}
                            rowsPerPage={this.state.rowsPerPage}
                            page={this.state.page}
                            onChangePage={this.handleChangePage}
                            onChangeRowsPerPage={this.handleChangeRowsPerPage} />
                    </Paper>
                </div>

            </div>
        );
    }
}

export default DataTable;