import React from "react";
import HistoryTable from "./table";
import * as ReactDOM from "react-dom";

describe("Table test", () => {
    it('renders header without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<HistoryTable />, div);
    });
});