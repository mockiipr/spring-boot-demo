import React, { Component } from "react";
import Modal from "@material-ui/core/Modal";
import "./Advanced-popover.scss";
import ATabContainer from './TabContainer';
import {
  Tab,
  Tabs,
  AppBar
} from '@material-ui/core';


interface PopoverProps {
  openModal?: boolean;
  onBackdropClick?: any;
  anchorEl?: any;
  id: any;
  close?: Function;
}

export default class AdvancedPopover extends Component<PopoverProps> {
  state = {
    value: 0,
  };
  handleClose() {
    this.props.close();
  }
  handleChange = (event, value) => {
    this.setState({ value });
  }

  a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    };
  }
  render() {
    const { openModal, onBackdropClick, anchorEl, id } = this.props;
    const { value } = this.state;
    return (
      <div className='advanced-popover-container'>
        <div className='advanced-search-header'>
          <span className='frequent-title'>Frequent Searches
              <img style={{ float: 'right' }} src={require('client/assets/images/close-24-px-2.png')} />

          </span>
          <input type="text" id="myInput" />
        </div>
        <div className='tab-component'>
          <AppBar position="static" color="default">
            <Tabs value={value} onChange={this.handleChange} textColor="primary" indicatorColor="primary" aria-label="simple tabs example">
              <Tab label="Week" {...this.a11yProps(0)} />
              <Tab label="Month" {...this.a11yProps(1)} />
              <Tab label="Year" {...this.a11yProps(1)} />
            </Tabs>
          </AppBar>
          {value === 0 && <ATabContainer>
            <div className="tab-content-container">
              <div className='plan-info'>
                <span>IRK123456</span>
                <span>Core General Constructions 401 PLan</span>
              </div>
              <div className='plan-info'>
                <span>IRK123456</span>
                <span>Core General Constructions 401 PLan</span>
              </div>
              <div className='plan-info'>
                <span>IRK123456</span>
                <span>Core General Constructions 401 PLan</span>
              </div>
              <div className='view-more'>
                <span >View More</span>
              </div>
            </div>
          </ATabContainer>}
          {value === 1 && <ATabContainer>
            <div>
              <span>IRK123456</span>
              <span>Core General Constructions 401 PLan</span>
            </div>
          </ATabContainer>}
          {value === 2 && <ATabContainer>
            <div>
              <span>IRK123456</span>
              <span>Core General Constructions 401 PLan</span>
            </div>
          </ATabContainer>}
        </div>
      </div >

    );
  }
}
