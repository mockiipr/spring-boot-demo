import React from 'react';
import {
    Typography
} from "@material-ui/core";

class ATabContainer extends React.Component {

    render() {
        return (
            <div>
                <Typography component="div" style={{ padding: '0px 15px 10px 15px' }}>
                    {this.props.children}
                </Typography>
            </div>
        )
    }
}
export default ATabContainer;
