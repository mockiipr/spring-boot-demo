import React from "react";
import Footer from "./Footer";
import * as ReactDOM from "react-dom";
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

configure({ adapter: new Adapter() });

describe("Table test", () => {
    it('renders header without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<Footer />, div);
    });
    it('should have header', () => {
        const _wrapper = shallow(<Footer />)
        expect(_wrapper.find('.footer-component')).toHaveLength(1)
    })
});