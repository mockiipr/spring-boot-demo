import React, { Component } from 'react';
//import { withRouter } from "react-router";
import { connect } from "react-redux";
import './header.scss';
import { Drawer } from "client/components";

class Header extends Component {

    render() {
        return (<div className="header-container">
            <div className="header-top-row">
                <div className="contact-us"></div>
                <div className="navbar">
                    <div className="drawer">
                        <Drawer />
                    </div>
                </div>
            </div>
            <div className="header-top-row">
            </div>
            <div className="header-middle-row">
                <div className="title">RPA Modernization</div>
            </div>
        </div>)
    }
}


const mapStateToProps = (state: any) => {
    return {

    };
};

export default connect(mapStateToProps)(Header);
//export default Header;