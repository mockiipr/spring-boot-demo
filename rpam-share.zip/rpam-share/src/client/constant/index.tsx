// routes
export const HOME_PAGE_URI = "/";
export const ALL_PLAN_SEARCH_PAGE_URI = "/allplansearch";
export const REMINDERS_PAGE_URI = "/reminders";
export const SOURCES_PAGE_URI = "/sources";
export const IMAGING_BOX_PAGE_URI = "/imaging-box";
export const GET_WORK_PAGE_URI = "/get-work";
export const WORKITEMS_PAGE_URI = "/workitems";
export const REPORTS_PAGE_URI = "/reports";
export const TOOLS_PAGE_URI = "/tools";

export const LOGOUT_PAGE_URI = "/logout";
export const AUTH_PAGE_URI = "/auth";
export const GET_STARTED_PAGE_URI = "/start";
export const PLAN_INITIATE_PAGE_URI = "/planinitiation";
export const PLAN_DETAILS_PAGE_URI = "/planDetails";
export const CONTACTS_PAGE_URI = "/contactDetails";
export const NEW_PLAN_PAGE_URI = "/newPlan";


// entitlements
export const READ_ACCESS = "read";
export const WRITE_ACCESS = "write";
//external links
export const PROSPECTUS_URI = "https://americanfundsretirement.retire.americanfunds.com/about/funds/funds-overview.htm";

//footer links
const cgLearingCenterPrefix = "https://www.capitalgroup.com/content/sites/american-funds/retirement/us/en/individual/education-site/learning-center"
export const PRIVACY_URI = `${cgLearingCenterPrefix}/privacy.html`;
export const SECURITY_URI = `${cgLearingCenterPrefix}/security.html`;
export const BUSINESS_CONTINUITY_URI = `${cgLearingCenterPrefix}/business-continuity.html`;
export const ETHICS_CODE_URI = `${cgLearingCenterPrefix}/code-of-ethics.html`;
export const TRADEMARKS_URI = `${cgLearingCenterPrefix}/legal-information.html`;
export const SYSTEM_REQUIREMENTS_URI = `${cgLearingCenterPrefix}/system-requirements.html`;

