import axios from 'axios';
const URL = process.env.REACT_APP_API_URL;

// Search List
export const getSearchData = (param: any) => {
    const config = {
        params: {
            searchText: param.searchText
        }
    };
    const request = axios.get(URL + '/api/search', config)
        .then(response => response.data)
    return {
        type: 'GET_SEARCH_LIST',
        payload: request
    }
}


// Associate List
export const getAssociateList = (params: any) => {
    const reqHeader = {
        headers: {
            "Access-Control-Allow-Origin": "*"
        }
    }
    const config =
    {
        "cgInitials": "",
        "firstName": "",
        "lastName": "",
        "roleId": "Client Coordinator",
        "teamManagerId": ""

    };
    const request =
        axios.post('https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service/associates/v1/search', config)//, reqHeader)
            .then(response => response.data.searchResults)
    return {
        type: 'GET_ASSOCIATE_LIST',
        payload: request
    }
}
