import React, { Component } from "react";
import { connect } from "react-redux";
import { Route } from "react-router";
import "./app-router.scss";
import { HashRouter as Router } from 'react-router-dom';
import {
  SOURCES_PAGE_URI,
  ALL_PLAN_SEARCH_PAGE_URI,
  IMAGING_BOX_PAGE_URI,
  REPORTS_PAGE_URI,
  REMINDERS_PAGE_URI,
  TOOLS_PAGE_URI,
  WORKITEMS_PAGE_URI,
  GET_WORK_PAGE_URI
} from "client/constant";
import { Header, Footer, Dashboard, ErrorHandler } from "client/components";
import { PlanSearch, GetWork, WorkItems, Tools, Reminders, Reports, ImagingBox, Sources} from 'client/pages'
import { Dispatch } from "redux";

export interface AppRouterProps {
  dispatch: Dispatch;
}

class AppRouter extends Component<AppRouterProps> {

  render() {
    return (
      <Router>
        <div className="app-container">
          <Header />
          <ErrorHandler>
            <div className="app-body">
              <Route exact path='/' component={Dashboard} />
              <Route exact path={ALL_PLAN_SEARCH_PAGE_URI} component={PlanSearch} />
              <Route exact path={SOURCES_PAGE_URI} component={Sources} />
              <Route exact path={IMAGING_BOX_PAGE_URI} component={ImagingBox} />
              <Route exact path={REPORTS_PAGE_URI} component={Reports} />
              <Route exact path={REMINDERS_PAGE_URI} component={Reminders} />
              <Route exact path={TOOLS_PAGE_URI} component={Tools} />
              <Route exact path={WORKITEMS_PAGE_URI} component={WorkItems} />
              <Route exact path={GET_WORK_PAGE_URI} component={GetWork} />
            </div>
          </ErrorHandler>
          <Footer />
        </div>
      </Router>
    );
  }
}

const mapStateToProps = (state) => {
  return {
  };
};

export default connect(mapStateToProps)(AppRouter);
