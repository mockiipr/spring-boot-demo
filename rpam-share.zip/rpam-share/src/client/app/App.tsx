import React from 'react';
import AppRouter from "client/app/app-router";
import { Provider } from 'react-redux';
import { store } from 'client/app-redux/store';

class App extends React.Component {
  componentDidMount() {
    // setTimeout(() => {
    //   let appState = getState();
    //   if (appState.profile.token) {
    //     // store.dispatch(logout());
    //   }
    // }, 5000);
  }
  render() {
    return (
      <Provider store={store}>
        <AppRouter />
      </Provider>
    );
  }
}


export default App;
