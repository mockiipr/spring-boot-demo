import * as utils from './Utils'

describe('src --> Utils', () => {
    it('Test isTablet', () => {
        const mockdata = "lorem ipsum lorem ipsum lorem ipsum";
        const mockfn = jest.fn().mockImplementation(utils.isTablet);
        mockfn(mockdata, 50);
        expect(mockfn).toHaveBeenCalled();
    })
    it('Test isMobile', () => {
        const mockdata = "lorem ipsum lorem ipsum lorem ipsum";
        const mockfn = jest.fn().mockImplementation(utils.isMobile);
        mockfn(mockdata, 50);
        expect(mockfn).toHaveBeenCalled();
    })
    it('Test isDesktop', () => {
        const mockdata = "lorem ipsum lorem ipsum lorem ipsum";
        const mockfn = jest.fn().mockImplementation(utils.isDesktop);
        mockfn(mockdata, 50);
        expect(mockfn).toHaveBeenCalled();
    })
})


