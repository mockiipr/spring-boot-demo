const BASE = 'RPAM-react-app';
const COLOURS = {
  trace: 'lightblue',
  info: 'blue',
  warn: 'pink',
  error: 'red'
}; // choose better colours :)


class Logging {
  level = 'All';
  logWithDate: boolean = true;
  formatParams(params: any[]): string {
    let ret: string = params.join(",");
    // Is there at least one object in the array?
    if (params.some(p => typeof p == "object")) {
      ret = "";
      // Build comma-delimited string
      for (let item of params) {
        ret += JSON.stringify(item) + ",";
      }
    }
    return ret;
  }
  debug(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'Debug', 'blue', optionalParams);
  }

  info(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'info', 'blue', optionalParams);
  }

  warn(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'warn', 'yellow', optionalParams);
  }

  error(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'error', 'red', optionalParams);
  }

  fatal(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'fatal', 'red', optionalParams);
  }

  log(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, 'info', 'blue', optionalParams);
  }

  writeToLog(msg: string, level: any, color: string, params: any[]) {
    const namespace = `${BASE} ${level}`;

    let value: string = ': ' + msg;
    if (params.length) {
      value += ' Extra Info: ' + this.formatParams(params);
    }
    console.log('%c ' + namespace + value, 'color: ' + COLOURS[level] + ';');
  }
}
export default Logging;
