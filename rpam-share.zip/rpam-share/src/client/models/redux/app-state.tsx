/* istanbul ignore file */
export interface AppState {
  profile: any;
}

export type Status = "PENDING" | "SENT" | "CANCELED" | "NOT DELIVERED" | null;
export class AssociateData {
  associateSuid: string = "";
  cgInitials: string = "";
  activeToDate: string = "";
  role: string = "";
  roleTypeDesc: string = "";
  roleTypeSuid: string = "";
  selectedAssociate: string = "";
  siteTypeSuid: string = "";
  siteType: string = "";
  specificSiteId: string = "";
  allowedToMoveSource: boolean;
  siteSpecific: boolean;
}

export class indexedBy {
  planIdNamePair?: any;
  accountNumber?: any;
  ssn?: any;
  alphaCode?: any;
}
export class DataGrid {
  appianTaskId: any = "";
  dateTime: string = "";
  assignee: string = '';
  indexedBy: indexedBy = {
    planIdNamePair: '',
    accountNumber: '',
    ssn: '',
    alphaCode: ''
  };
  planName: string = "";
  subjectLine: string = "";
  taxId?: string = "";
  workType?: string = '';
  serviceType: string = "";
  TPAName: string = "";
  planStatus: string = "";
  planId?: string = "";
  dealerName?: string = "";
  dealerRepName?: string = "";
  Notes?: string = "";
  tpaTaxID?: string = "";
  tpaAddress?: string = "";
  tpaEmailAddress?: string = "";
  tpaPhNumber?: string = "";
  repName?: string = "";
  repID?: string = "";
  constructor(dataGridItem?: DataGrid) {
    if (dataGridItem) {
      this.dateTime = dataGridItem.dateTime;
      this.assignee = dataGridItem.assignee;
      this.indexedBy = dataGridItem.indexedBy;
      this.planName = dataGridItem.planName;
      this.workType = dataGridItem.workType;
      this.subjectLine = dataGridItem.subjectLine;
      this.planId = dataGridItem.planId;
    }
  }

}