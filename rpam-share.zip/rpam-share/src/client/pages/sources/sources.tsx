import React, { Component } from "react";

class Sources extends Component {
  render() {
    return (
      <div className="container">
        <div className="page-header">Sources Page</div>
      </div>
    );
  }
}

export default Sources;