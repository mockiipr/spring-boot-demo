import React, { Component } from "react";
//import { connect } from "react-redux";
import "./PlanSearch.scss";

import { PlanLookup } from "client/components";

class PlanSearch extends Component {
  render() {
    return (
      <div>
        <PlanLookup />
      </div>
    );
  }
}

export default PlanSearch;
