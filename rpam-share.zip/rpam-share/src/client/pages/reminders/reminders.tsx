import React, { Component } from "react";
import Button from '@material-ui/core/Button';
import axios from "axios";

interface MyState { 
  data: any
};

interface MyProps { 
};

class Reminders extends Component<MyProps, MyState> {
  constructor(props) {
    super(props);

    this.state = {
        data : ''
    };

    this.callAPI = this.callAPI.bind(this)

  }

  callAPI(){
    this.setState({ data: {"data": "Please Wait...."} });
    let url = process.env.REACT_APP_API_URL
    // axios.get(`${url}/api/getMeJson`).then((res) => {
    const config = {
        params: {
            searchText: 'mockdata-TIN1'
        }
    };
    axios.get(url + `/api/search`, config).then((res) => {
      this.setState({ data:res.data });
    }).catch(error => {
      console.log(error);
      this.setState({ data: {"data": "No Response from server, check if server is running"} });
    });
  }

  render() {
    return (
      <div className="container">
        <div className="page-header">Reminders Page
        <Button style={{margin: '10px'}} variant="contained" onClick={this.callAPI} color="primary">Hello</Button>
          {this.state.data.isMockData === true ? <h2>This is Mock Data, Request to AWS server has been failed</h2> : null}
          {JSON.stringify(this.state.data.value)}
        </div>
      </div>
    );
  }
}

export default Reminders;