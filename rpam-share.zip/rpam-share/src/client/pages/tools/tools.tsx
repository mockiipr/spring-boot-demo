import React, { Component } from "react";

class Tools extends Component {
  render() {
    return (
      <div className="container">
        <div className="page-header">Tools Page</div>
      </div>
    );
  }
}

export default Tools;