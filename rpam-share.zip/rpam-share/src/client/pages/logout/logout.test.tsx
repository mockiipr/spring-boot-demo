import React from "react";
import Logout from "./logout";
import * as ReactDOM from "react-dom";
import { shallow, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

configure({ adapter: new Adapter() });

describe("logout test", () => {
    it('renders  without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<Logout />, div);
    });
    it('should have h2', () => {
        const _wrapper = shallow(<Logout />)
        expect(_wrapper.find('h2')).toHaveLength(1)
    })
});