'use strict';
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const http = require('http');
const fs = require('fs');
const path = require('path');
const log4js = require('log4js');
const Config = require('./config/config');
const config = new Config();

const SearchRouter = require('./routers/search_router').SearchRouter;

const logDirectory = path.join(__dirname, 'log');
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

//logging configuration
log4js.configure(__dirname + '/log4js-config.json', {reloadSecs: 60, cwd: logDirectory});
var logger = log4js.getLogger('server'),
    clientLogger = log4js.getLogger('client'),
    httpLogger = log4js.getLogger('http');

logger.info('Starting the CG server');

app.use(log4js.connectLogger(httpLogger, { level: 'auto' }));

// React
app.use(express.static(path.join(__dirname, '../../build')));

// Body Parser Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(function(req, res, next) { // NOSONAR
  res.header("Access-Control-Allow-Origin", "*"); // NOSONAR
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept"); // NOSONAR
  next(); // NOSONAR
}); // NOSONAR

app.use('/api',new SearchRouter().getRoutes());

// app.use('/',(req, res)=>{
//     res.send('Invalid Endpoint');  
// });

// React
app.get('/', (req,res) => {
    res.sendFile(path.join(__dirname, '../../build/index.html'));
});

// const port = process.env.PORT || 7070;

const server = http.createServer(app);

app.listen(config.server.port, () => {
    console.log('Server started at port ' + config.server.port);
});
