module.exports = function(){
    switch(process.env.NODE_ENV){
        case 'production':
            return {
                application: {
                    name: 'Retirement Plan Services Modernization (RPAM)'
                },
                oauth: {
                    clientID: "RPAM",
                    clientSecret: "application data is my life",
                    url: "https://sso.captialgroup.com/oauth2.0",
                    nodeBaseURL: "https://rpam.captialgroup.com",
                    autoLogoutOnSessionExpired: "true"
                },
                server: {
                    port: 8081,
                    rootContext: '/ui',
                    logPath: '/applogs/rpam'
                },
                urls: {
                    rpam: 'https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service',
                    sso: 'https://sso.captialgroup.com'
                }
            };
            case 'development':
            return {
                application: {
                    name: 'Retirement Plan Services Modernization (RPAM)'
                },
                oauth: {
                    clientID: "RPAM",
                    clientSecret: "application data is my life",
                    url: "https://ssodev.captialgroup.com/oauth2.0",
                    nodeBaseURL: "https://rpamdev.captialgroup.com",
                    autoLogoutOnSessionExpired: "true"
                },
                server: {
                    port: 8082,
                    rootContext: '/ui',
                    logPath: '/applogs/rpam/dev'
                },
                urls: {
                    rpam: 'https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service',
                    sso: 'https://ssodev.captialgroup.com'
                },
                clientLogger: {
                    flushInterval: 600000, // 10 mins
                    maxLogLength: 10000,
                    isDebugEnabled: true,
                    enableLogService: true
                },
            };
        case 'qa':
            return {
                application: {
                    name: 'Retirement Plan Services Modernization (RPAM)'
                },
                oauth: {
                    clientID: "RPAM",
                    clientSecret: "application data is my life",
                    url: "https://ssoqas.captialgroup.com/oauth2.0",
                    nodeBaseURL: "https://rpamqas.captialgroup.com",
                    autoLogoutOnSessionExpired: "true"
                },
                server: {
                    port: 8083,
                    rootContext: '/ui',
                    logPath: '/applogs/rpam/qas'
                },
                urls: {
                    rpam: 'https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service',
                    sso: 'https://ssoqas.captialgroup.com'
                },
                clientLogger: {
                    flushInterval: 600000, // 10 mins
                    maxLogLength: 10000,
                    isDebugEnabled: true,
                    enableLogService: true
                },
            };
        default:
            return {
                application: {
                    name: 'Retirement Plan Services Modernization (RPAM)'
                },
                oauth: {
                    clientID: "RPAM Local",
                    clientSecret: "application data is my life",
                    url: "https://ssodev.captialgroup.com/oauth2.0",
                    autoLogoutOnSessionExpired: "true"
                },
                server: {
                    port: 3001,
                    rootContext: '/ui',
                    logPath: __dirname + '/logs'
                },
                urls: {
                    rpam: 'https://apigw.rpam.aws-dev.capgroup.com/dev/rps/plan-service',
                    sso: 'https://ssodev.captialgroup.com'
                },
                clientLogger: {
                    flushInterval: 600000, // 10 mins
                    maxLogLength: 10000,
                    isDebugEnabled: true,
                    enableLogService: true
                },
            };
    }
};