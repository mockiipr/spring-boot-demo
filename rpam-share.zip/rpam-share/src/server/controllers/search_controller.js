'use strict';

const axios = require('axios')
let config = require('../config/config')
let env = process.env.NODE_ENV
let EnvConfig = config(env);
let server_url = EnvConfig.urls.rpam;
// let python_server_url = 'http://192.168.0.8:5200/api'
// Mock Data JSON Files
const search = require('../fs/search-table.json');
const recentSearches = require('../fs/recent-searches.json');
const associates = require('../fs/associates.json');
const frequentSearches = require('../fs/frequent_searches.json');
const plans = require('../fs/plans.json');

class SearchController {

  constructor() { }

  search() {
    let getSearch = function (req, res, next) {
      let requestData = {
        "search": {
          "searchText": req.query.searchText
        }
      };
      axios.post(`${server_url}/plans/v1/search`, requestData)
      .then(res => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(data);
      })
      .catch(error => {
        console.log(error);
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(search, null, 3))
      })
    }

    return getSearch;
  }

  associates() {
    let getAssociates =  function (req, res, next) {
      let requestData = {
        "search": {
          "searchText": req.query.searchText
        }
      };
      axios.post(`${server_url}/associates/v1/search`, requestData)
      .then(res => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(data);
      })
      .catch(error => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(associates, null, 3))
      })
    }
    return getAssociates;

  }

  recent_searches() {
    let getRecentSearches = function (req, res, next) {
      axios.post(`${server_url}/recent_searches/v1/search`)
      .then(res => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(data);
      })
      .catch(error => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(recentSearches, null, 3))
      })
    }
    return getRecentSearches;
  }

  frequent_searches() {
    let getFrequentSearches = function (req, res, next) {
      axios.post(`${server_url}/frequent_searches/v1/search`)
      .then(res => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(data);
      })
      .catch(error => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(frequentSearches, null, 3))
      })
    }
    return getFrequentSearches;

  }

  plans() {
    let getPlans = function (req, res, next) {
      axios.post(`${server_url}/all_plans/v1/search`)
      .then(res => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(data);
      })
      .catch(error => {
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(plans, null, 3))
      })
    }

    return getPlans;

  }

  faker() {
    // let faker_data = function (req, res, next) {
    //   http.get(`${python_server_url}/get`, (resp) => {
    //     let data = '';
    //     resp.on('data', (chunk) => {
    //       data += chunk;
    //     });
    //     resp.on('end', () => {
    //       res.header("Content-Type", 'application/json');
    //       res.status(200).send(data);
    //     });

    //   }).on("error", (err) => {
    //     let data = {"data": "Error:404 Python API failed"}
    //     // Mock Data on error
    //     res.header("Content-Type", 'application/json');
    //     res.status(500).send(JSON.stringify(err, null, 3));
    //   });
    // }
    // return faker_data;

    let data = function (req, res, next) {
        let data = {"data": "Hey there, from " + env + " server"}
        res.header("Content-Type", 'application/json');
        res.status(200).send(JSON.stringify(data, null, 3));
    }
    return data;

  }

}

exports.SearchController = SearchController;