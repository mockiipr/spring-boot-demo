import { WRITE_ACCESS, READ_ACCESS } from "client/constant";

export function hasWriteAccess(entitlement: string): boolean {
  return entitlement === WRITE_ACCESS;
}

export function hasReadAccess(entitlement: string): boolean {
  return entitlement === READ_ACCESS;
}
