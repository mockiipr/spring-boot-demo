//import * as moment from "moment";

export function isDefaultTime(date: string): boolean {
  return date === "0001-01-01T00:00:00";
}

// export const dateFormat = (date: string) => {
//   return date ? moment.utc(date).format("MM / DD / YYYY") : "";
// };

// export function yearFormat(date: string): string {
//   return date ? moment.utc(date).format("YYYY") : "";
// };

// export function monthFormat(date: string): string {
//   return date ? moment.utc(date).format("MMM") : "";
// };

// export function dayFormat(date: string): string {
//  //return date ? moment.utc(date).format("DD") : "";
// };

export const moreLinkFormat = (value: string, showChar: number) => {
  let contentToDisplay: string = value;
  let ellipsestext: string = "";

  if (value && value.length > showChar) {
    contentToDisplay = value.substr(0, showChar);
    ellipsestext = " more…";
  }

  return {
    contentToDisplay,
    ellipsestext
  };
};


export const ellipsisText = (value: string, showChar: number) => {
  let contentToDisplay: string = value;
  if (contentToDisplay.length > showChar) {
    contentToDisplay = value.substr(0, showChar) + "...";
  }
  return {
    contentToDisplay,
  };
};

export type Order = "asc" | "desc";
export const ascendingOrder: Order = "asc";
export const descendingOrder: Order = "desc";

function desc<T>(a: T, b: T, orderBy: keyof T) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

export function stableSort<T>(array: T[], cmp: (a: T, b: T) => number): T[] {
  const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
}

export function getSorting<T>(order: string, orderBy: keyof T): (a: { [key in keyof T]: any }, b: { [key in keyof T]: any }) => number {
  return order === descendingOrder ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

export function isDesktop(): boolean {
  return window.screen.width > 768;
}

export function isTablet(): boolean {
  return window.screen.width <= 768 && window.screen.width > 375;
}

export function isMobile(): boolean {
  return window.screen.width <= 375;
}