import axios, { AxiosInstance, AxiosError, AxiosRequestConfig } from "axios";
import { getState, store } from "client/app-redux/store";

class HttpClient {
  axiosInstance: AxiosInstance;

  constructor() {
    this.axiosInstance = axios.create({
      baseURL: "/preferences/api",
      headers: {
        contentType: "application/json"
      }
    });
    this.createRequestInterceptor();
  }

  createRequestInterceptor() {
    this.axiosInstance.interceptors.request.use(
      (config: AxiosRequestConfig) => {
        config.headers.authorization = `Bearer ${getState().profile.token}`;
        return config;
      }
    );
  }



  post<Request, Response>(url: string, body: any) {
    return this.axiosInstance.post<Request, Response>(url, body);
  }

  get<Request, Response>(url: string) {
    return this.axiosInstance.get<Request, Response>(url);
  }
}

export default HttpClient;
