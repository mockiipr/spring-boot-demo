import HttpClient from "./http-client";

export default class RPAWebService {
  httpClient: HttpClient;

  constructor() {
    this.httpClient = new HttpClient();
  }

  getData() {
    return this.httpClient.get("/api-service/getData");
  }

  refreshToken() {
    return this.httpClient.get("/api-service/auth/refresh");
  }
}
