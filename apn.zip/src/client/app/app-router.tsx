import React, { Component } from "react";
import { connect } from "react-redux";
import { Route } from "react-router";
import "./app-router.scss";
import { BrowserRouter as Router } from 'react-router-dom';
import {
  HOME_PAGE_URI,
} from "client/constant";
import { Dashboard, ErrorHandler } from "client/components";
import { Dispatch } from "redux";

export interface AppRouterProps {
  dispatch: Dispatch;
}

class AppRouter extends Component<AppRouterProps> {

  onErrorDismiss = () => {
    this.setState({ showError: false });
  };

  render() {
    return (
      <Router>
        <ErrorHandler>
          <div className="app-body">
            <Route path={HOME_PAGE_URI} component={Dashboard} />
          </div>
        </ErrorHandler>
      </Router>
    );
  }
}

const mapStateToProps = (state) => {
  return {
  };
};

export default connect(mapStateToProps)(AppRouter);
