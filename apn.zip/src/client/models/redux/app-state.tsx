/* istanbul ignore file */
export interface AppState {
  profile: any;
}

export type Status = "PENDING" | "SENT" | "CANCELED" | "NOT DELIVERED" | null;

export class DataGrid {
  dateUpload: string = "";
  assignee: string = '';
  indexedBy: string = "";
  planName: string = "";
  serviceType: string = "";
  subject: string = "";
  
  pageCount?: number | null = null;

  statusUpdateReason?: string = "";
  statusUpdateInitiator?: string = "";
  status?: Status = null;

  constructor(dataGridItem?: DataGrid) {
    if (dataGridItem) {
      this.dateUpload = dataGridItem.dateUpload;
      this.assignee = dataGridItem.assignee;
      this.indexedBy = dataGridItem.indexedBy;
      this.planName = dataGridItem.planName;
      this.serviceType = dataGridItem.serviceType;
      this.subject = dataGridItem.subject;
      
      this.pageCount = dataGridItem.pageCount;
     
      this.status = dataGridItem.status;
    }
  }

  setPlanDetails?(planId: string, planName: string) {
   
    this.planName = planName;
  }

  

  setFileDetails?(
    pdfFileName: string,
    csvFileName: string,
    description: string,
    pageCount: number | null,
    participantCount: number | null
  ) {
    
    this.pageCount = pageCount;
  //  this.participantCount = participantCount;
  }
}