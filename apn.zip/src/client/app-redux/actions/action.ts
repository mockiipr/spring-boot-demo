import axios from 'axios';
const URL = 'http://localhost:2000';

export const receivedList = (data) => {
    return {
        type: 'LOAD_LIST',
        data
    }
}

export const logout = () => {
    const profile = {};
    return { type: 'LOG_OUT', profile };
}

export const getList = () => {
    return (dispatch) => {
        return fetch('url')
            .then(response => response.json())
            .then(data => dispatch(receivedList(data)));
    }
}
// APPIAN Search API
export const searchResults = (object) => {
    const params = {
        plan_id: object.plan_id,
        start_index:object.startIndex,
        end_index:object.endIndex,
    };
    const request = axios.get(URL + '/get/search', {params})
        .then(response => response.data)
    return {
        type: 'GET_SEARCH_RESULTS',
        payload: request
    }
}
