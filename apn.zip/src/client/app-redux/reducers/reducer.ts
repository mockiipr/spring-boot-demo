const initalState = {
    list: []
};

export function handleEventReducer(state = initalState, action) {
    switch (action.type) {
        case "LOAD_LIST": {
            const stateObj = {
                list: action.data
            }
            return Object.assign({}, state, stateObj);
        }
        case "GET_SEARCH_RESULTS": {
            return {...state, searchResults:action.payload}
        }
        default:
            return state
    }
}