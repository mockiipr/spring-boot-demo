import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { handleEventReducer } from 'client/app-redux';
import { AppState } from "client/models";
import promiseMiddleware from 'redux-promise';

export const store = createStore(handleEventReducer, applyMiddleware(thunk, promiseMiddleware));

export const getState = (): AppState => {
    const item = window.sessionStorage.getItem("redux-store");
    return item === null ? {} : JSON.parse(item);
};

//export default store;