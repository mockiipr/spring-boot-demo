import React from "react";
import "./SearchWidget.scss";
import TuneIcon from '@material-ui/icons/Tune';
import {
    TextField,
    Paper,
    InputLabel,
    createStyles,
    Select,
    makeStyles,
    MenuItem,
    FormControl,
    Theme,
    Divider,
    Button,
    Box,
} from "@material-ui/core";


const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    textField: {
      marginLeft: theme.spacing(3),
      marginRight: theme.spacing(3),
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(2),
      minWidth: 255,
    },
    cardTitle:{
        margin:theme.spacing(2)
    },
    date: {
      marginTop: theme.spacing(1),
      marginBottom: theme.spacing(2),
      marginLeft: theme.spacing(2),
      marginRight: theme.spacing(2),
      minWidth: 115,
    },
    searchButton: {
        float:'right',
    },
    resetButton: {
        float:'right',
        marginRight: theme.spacing(3),
    },
    icon: {
        marginBottom:'-6px'
    },
    searchForm: {
      marginTop: theme.spacing(2),
      marginBottom: theme.spacing(1),
    },
    searchResult: {
        marginTop: theme.spacing(4),
        marginBottom: theme.spacing(2),
    },
  })
);

interface SearchProps {
    searchObject:any;
}

const SearchWidget: React.FC<SearchProps> = (props:SearchProps) => {
    const [planID, setPlanID] = React.useState(null);
    let searchObj:any = {}
    const classes = useStyles();

    const searchCall = () => {
        searchObj = {
            plan_id: planID,
            startIndex: 1,
            endIndex:10,
        }
        if(planID !== null){
            props.searchObject(searchObj)
        }
    }

    const resetSearch = () => {
        setPlanID('');
        props.searchObject('reset')
    }
    return (
            <div>
                <div className="container">
                    <Paper>
                        <Box className={classes.cardTitle} textAlign="left" fontSize={18} fontWeight={500}>
                            Search Criteria <TuneIcon className={classes.icon}/>
                            <Button className={classes.searchButton} onClick={searchCall} variant="outlined"
                                    color="primary">Search</Button>
                            <Button className={classes.resetButton} onClick={resetSearch} color="primary">Reset
                                Fields</Button>
                        </Box>
                        <Divider/>
                        <form className={classes.searchForm} noValidate autoComplete="off">
                            <TextField
                                className={classes.textField}
                                id="social-security"
                                label="Social Security"
                                margin="normal"
                                variant="filled"
                                disabled={true}
                            />
                            <TextField
                                className={classes.textField}
                                id="account-number"
                                label="Account Number"
                                margin="normal"
                                variant="filled"
                                disabled={true}
                            />
                            <TextField
                                className={classes.textField}
                                id="plan-id"
                                label="Plan ID"
                                margin="normal"
                                variant="filled"
                                name="planID"
                                value={planID}
                                onChange={e => setPlanID(e.target.value)}
                                // onChange={event => props.searchObject(event)}
                            />
                            <TextField
                                className={classes.textField}
                                id="code"
                                label="Alpha Code"
                                margin="normal"
                                variant="filled"
                                disabled={true}
                            />
                            <FormControl variant="filled" className={classes.textField}>
                                <InputLabel id="demo-simple">Service Type</InputLabel>
                                <Select labelId="service-type" id="service-type" disabled={true}>
                                    <MenuItem value={0}>
                                        <em></em>
                                    </MenuItem>
                                    <MenuItem value={1}>Type 1</MenuItem>
                                    <MenuItem value={2}>Type 2</MenuItem>
                                    <MenuItem value={3}>Type 3</MenuItem>
                                </Select>
                            </FormControl>
                            <FormControl variant="filled" className={classes.date} disabled={true}>
                                <InputLabel id="demo-simple-select">Start Year</InputLabel>
                                <Select labelId="start-year" id="start-year">
                                    <MenuItem value={0}>
                                        <em></em>
                                    </MenuItem>
                                    <MenuItem value={2020}>2020</MenuItem>
                                    <MenuItem value={2019}>2019</MenuItem>
                                    <MenuItem value={2018}>2018</MenuItem>
                                </Select>
                            </FormControl>
                            <FormControl variant="filled" className={classes.date} disabled={true}>
                                <InputLabel id="demo-simple-select-filled-label">
                                    End Year
                                </InputLabel>
                                <Select labelId="end-year" id="end-year">
                                    <MenuItem value={0}>
                                        <em></em>
                                    </MenuItem>
                                    <MenuItem value={2020}>2020</MenuItem>
                                    <MenuItem value={2019}>2019</MenuItem>
                                    <MenuItem value={2018}>2018</MenuItem>
                                </Select>
                            </FormControl>
                        </form>

                    </Paper>
                </div>
            </div>

    );
}

export default SearchWidget;