import React from "react";
import "./NoResults.scss";
import TableChartSharpIcon from '@material-ui/icons/TableChartSharp';
import { Paper } from "@material-ui/core";

class NoResults extends React.Component {
  render() {
    return (
        <div>
          <div className="container outer-margin">
            <Paper>
              <div className="text-center inner-margin">
                <TableChartSharpIcon style={{fontSize: '70px'}} color="primary"/>
                <h2>No Results Found!</h2>
                <p className="message">Please refine your search and try again.</p>
              </div>
            </Paper>
          </div>
        </div>
    );
  }
}

export default NoResults;
