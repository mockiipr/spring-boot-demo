import React, {Component} from 'react';
import {ErrorHandler, SearchResult, SearchWidget} from 'client/components';
import {searchResults} from "../../app-redux";
import {connect} from "react-redux";
import {SyncLoader} from "react-spinners";
import { css } from "@emotion/core";

interface MyProps{
    getResults:any;
    search:any;
    results:any;
}

const loader = css`
  display: block;
  text-align: center;
  font-size:50px;
`;
export class AppianWorkItems extends Component<MyProps> {
    constructor(props:MyProps) {
        super(props);


    }

    state = {
        data:'no_data',
        searchObject:null,
    }

   getSearchObject = (event) => {
       if(event == 'reset'){
           this.setState({ data: 'no_data' })
       } else {
           this.setState({data: 'no_data'});
           this.setState({searchObject: event});
           // GET Action
           this.props.search(event)
           // GET Data
           // setTimeout(() => {
           //  this.setState({data: this.props.results});
           // }, 3500)
       }

   };

    UNSAFE_componentWillReceiveProps(props){
        this.setState({data: props.results});
    }

    render() {
        return (
            <ErrorHandler>
                <SearchWidget searchObject={this.getSearchObject}/>
                {this.state.searchObject !== null && this.state.data == 'no_data' ? <SyncLoader css={loader} color={"#3f51b5"} loading={true}/> :null }
                {this.state.data == 'no_data' || this.state.data == undefined ? null : <SearchResult getResults={this.state.data} searchedObject={this.state.searchObject}/> }
            </ErrorHandler>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        results: state.searchResults
    };
};
const mapDispatchToProps = dispatch => {
    return {
        search:object => dispatch(searchResults(object))
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(AppianWorkItems);
