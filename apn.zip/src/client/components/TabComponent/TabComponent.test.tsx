import React from "react";
import TabComponent from "./TabComponent";
import * as ReactDOM from "react-dom";

describe("Table test", () => {
    it('renders header without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<TabComponent />, div);
    });
});