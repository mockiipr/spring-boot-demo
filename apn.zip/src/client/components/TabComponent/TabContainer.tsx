import React from 'react';
import {
    Typography
} from "@material-ui/core";

class TabContainer extends React.Component {
   
    render() {
        return (
            <div>
                <Typography component="div" style={{ padding: 8 * 3 }}>
                    {this.props.children}
                </Typography>
            </div>
        )
    }
}
export default TabContainer
