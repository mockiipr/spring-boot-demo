import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import TabContainer from './TabContainer';
import { DataGrid } from "client/models";
import {
    Tab,
    Tabs,
    AppBar
} from '@material-ui/core';

import {
    AppianWorkItems,
    TableGrid
} from 'client/components';

const data: DataGrid[] = [{
    dateUpload: "18/09/2020",
    assignee: 'BR01WQ',
    indexedBy: "C&G Privates",
    planName: " 500 plan",
    serviceType: "S TYpe 34567",
    subject: "This is dummy subject, this is a long subject line, a very very long subject line",
},
    {
        dateUpload: "18/09/2020",
        assignee: 'BR03WQ',
        indexedBy: "C&G Privates",
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        subject: "This is dummy subject",
    },
    {
        dateUpload: "18/09/2020",
        assignee: 'BR03WQ',
        indexedBy: "C&G Privates",
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        subject: "This is dummy subject",
    },
    {
        dateUpload: "18/09/2020",
        assignee: 'BR03WQ',
        indexedBy: "C&G Privates",
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        subject: "This is dummy subject",
    },
    {
        dateUpload: "18/09/2020",
        assignee: 'BR03WQ1',
        indexedBy: "C&G Privates",
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        subject: "This is dummy subject",
    },
    {
        dateUpload: "18/09/2020",
        assignee: 'BR01WQ',
        indexedBy: "C&G Privates",
        planName: " 500 plan",
        serviceType: "S TYpe 34567",
        subject: "This is dummy subject",
    }]
const styles = theme => ({
    root: {
        flexGrow: 1,
        width: '100%',
        backgroundColor: theme.palette.background.paper,
    },
});

class ScrollableTabsButtonAuto extends React.Component {
    state = {
        value: 0,
    };

    handleChange = (event, value) => {
        this.setState({ value });
    }

    a11yProps(index) {
        return {
            id: `simple-tab-${index}`,
            'aria-controls': `simple-tabpanel-${index}`,
        };
    }

    render() {
        const { value } = this.state;
        return (
            <div className='root'>
                <AppBar position="static" color="default">
                    <Tabs value={value} onChange={this.handleChange} textColor="primary" indicatorColor="primary" aria-label="simple tabs example">
                        <Tab label="Inbox" {...this.a11yProps(0)} />
                        <Tab label="Appian Work Items" {...this.a11yProps(1)} />
                    </Tabs>
                </AppBar>
                {value === 0 && <TabContainer>
                    <div className='buttons'>
                        {/* <Button id="appianButton" onClick={() => { }}>
                            Appian work items
                     </Button>
                        <Button id="appianButton" onClick={() => { }}>
                            AWD Sources
                     </Button> */}
                        <div className="container">
                            <TableGrid notices={data} />
                            {/* <Table /> */}

                        </div>
                    </div>
                </TabContainer>}
                {value === 1 && <TabContainer>
                    <AppianWorkItems getResults={'0'} />
                </TabContainer>}
            </div>
        );
    }
}


export default withStyles(styles)(ScrollableTabsButtonAuto);
