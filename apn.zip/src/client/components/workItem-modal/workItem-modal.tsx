import React, { Component } from "react";
import './workItem-modal.scss';
import Modal from "@material-ui/core/Modal";
import { isIE, isEdge } from "react-device-detect";
import { connect } from "react-redux";
import classNames from "classnames";
import { Dispatch } from "redux";
import ArrowForwardIcon from "@material-ui/icons/ArrowForward";
import WarningIcon from "@material-ui/icons/Warning";
import Button from "@material-ui/core/Button";
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
const classes: any = require('./workItem-modal.scss')

interface WorkItemModalProps {
  openModal: boolean;
  onClose: Function;
}

class WorkItemModal extends Component<WorkItemModalProps> {
  handleChange = (event) => {
    this.setState({ age: event.target.value })
    this.props.onClose();
  }

  render() {
    const { openModal, onClose } = this.props;

    return (
      <div className="progress-modal-container">
        <Modal open={openModal}>
          <div className={classNames({
            "modal": true,
            "internet-explorer": isIE || isEdge
          })}>
            <div className="Move-Workitem">Move Workitem</div>
            <div className="modal-text ">Please select the associate's initials to move</div>
            <FormControl variant="filled" className={classes.formControl}>
              <InputLabel id="demo-simple-select-filled-label">Agdde</InputLabel>
              <Select
                labelId="demo-simple-select-filled-label"
                id="demo-simple-select-filled"
                value={1}
                onChange={e => this.handleChange(e)}
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </div>
        </Modal>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {

  }
}
export default WorkItemModal
//export default connect(null, mapDispatchToProps)(TimeoutModal);