import React, {Component} from "react";
import "./SearchResult.scss";
import {NoResults} from "../index";
import {searchResults} from "../../app-redux";
import {connect} from "react-redux";
import {
  Table,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
  TablePagination,
  Paper,
  Divider,
  Box,
} from "@material-ui/core";

import TableSortLabel from '@material-ui/core/TableSortLabel';

function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}


function getComparator(order, orderBy) {
    return order === 'desc'
        ? (a, b) => descendingComparator(a, b, orderBy)
        : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

function EnhancedTableHead(props) {
    const { classes, order, orderBy, onRequestSort } = props;
    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };


    return (
        <TableHead>
            <TableRow>
                {columns.map((columns) => (
                    <TableCell
                        key={columns.id}
                        align={'left'}
                        style={{minWidth: columns.minWidth}}
                        sortDirection={orderBy === columns.id ? order : false}
                    >
                        <TableSortLabel
                            active={orderBy === columns.id}
                            direction={orderBy === columns.id ? order : 'asc'}
                            onClick={createSortHandler(columns.id)}
                        >
                            {columns.label}
                            {orderBy === columns.id ? (
                                <span className="visuallyHidden">
                                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                                </span>
                            ) : null}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}

const columns = [
  { id: "ssn", label: "Social Security", minWidth: 170 },
  { id: "planId", label: "Plan ID", minWidth: 100 },
  {
    id: "accountNumber",
    label: "Account Number",
    minWidth: 170,
    align: "right",
    format: (value: any) => value.toLocaleString("en-US"),
  },
  {
    id: "alphaCode",
    label: "Alpha Code",
    minWidth: 170,
    align: "right",
    format: (value: any) => value.toLocaleString("en-US"),
  },
  {
    id: "workType",
    label: "Work Type",
    minWidth: 170,
    align: "right",
    format: (value: any) => value.toLocaleString("en-US"),
  },
  {
    id: "assignee",
    label: "Assignee",
    minWidth: 170,
    align: "right",
    format: (value: any) => value.toLocaleString("en-US"),
  },
  {
    id: "dateTime",
    label: "Date/Time",
    minWidth: 170,
    align: "right",
    format: (value: any) => value.toLocaleString("en-US"),
  },
];


const rows = [
  createData("333-22-4444","BRK40502","10202445","3465","Lorem Impum dolor","BROQ1QW","07/05/2020 12:06:17")
];

function createData(socialSecurity, planID, accountNumber, alphaCode, workType, assignee, date) {
  return { socialSecurity, planID, accountNumber, alphaCode, workType, assignee, date };
}

interface TableState {
  showPopup: boolean;
  page: number;
  rowsPerPage: number;
  resultsData:any;
  totalResults:any;
}

interface MyProps{
  getResults:any;
  searchedObject:any;
  results:any;
  search:any;
}


export class SearchResult extends Component<MyProps> {

constructor(props: MyProps) {
  super(props);
}

 state = {
    showPopup: false,
    page: 0,
    rowsPerPage: 10,
    order: 'asc',
    orderBy: 'ssn',
    resultsData:null,
    totalResults:0
  }

  UNSAFE_componentWillMount() {
      if(this.props.getResults !== null) {
        this.setState({resultsData: this.props.getResults.users})
        this.setState({totalResults: this.props.getResults.results})
      }
  }

  UNSAFE_componentWillReceiveProps(newData) {
    if(newData !== null) {
      this.setState({resultsData: newData.getResults.users})
      this.setState({totalResults: newData.getResults.results})
    }
  }

    handleRequestSort = (event, property) => {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';
        this.setState({ order: isAsc ? 'desc' : 'asc' });
        this.setState({ orderBy: property });
    };

  handleChangePage = (event, newPage) => {
    this.setState({ page: newPage });
    this.callAPIOnPagination(newPage, this.state.rowsPerPage);
  };

  handleChangeRowsPerPage = (event) => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
      this.callAPIOnPagination(0, event.target.value);
  };

  callAPIOnPagination = (newPage, row) => {
    let startIndex = newPage*row + 1;
    let endIndex = (newPage*row) + (row);
    let searchObject = this.props.searchedObject;
      let searchObj = {
          plan_id: searchObject.plan_id,
          startIndex: startIndex,
          endIndex:endIndex,
      }
    // Search
    this.props.search(searchObj);
    // GET Data
    setTimeout(() => {
        this.setState({resultsData: this.props.results.users})
        this.setState({totalResults: this.props.results.results})
    }, 3500)
  };

  render() {
    let { page, rowsPerPage } = this.state;
    return (
          <div>
            {this.state.resultsData == 'no_data' || this.state.resultsData == undefined ? <NoResults/> :
                <div className="table-component">
                  <div className="table-wrapper">
                    <Paper>
                      <Box className="result-count" textAlign="right" fontSize={15} fontWeight={500}>
                        {this.state.totalResults} Results
                      </Box>
                      <Divider/>
                      <Table stickyHeader aria-label="sticky table" className="table">
                        {/*<TableHead className="table-head">*/}
                        {/*  <TableRow>*/}
                        {/*    {columns.map((column) => (*/}
                        {/*        <TableCell*/}
                        {/*            key={column.id}*/}
                        {/*            align={"left"}*/}
                        {/*            style={{minWidth: column.minWidth}}*/}
                        {/*        >*/}
                        {/*          {column.label}*/}
                        {/*        </TableCell>*/}
                        {/*    ))}*/}
                        {/*  </TableRow>*/}
                        {/*</TableHead>*/}
                        <EnhancedTableHead
                            order={this.state.order}
                            orderBy={this.state.orderBy}
                            onRequestSort={this.handleRequestSort}
                        />
                        <TableBody className="table-body">
                          {stableSort(this.state.resultsData, getComparator(this.state.order, this.state.orderBy))
                              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                              .map((row, i) => {
                                return (
                                    <TableRow
                                        className="body-row"
                                        hover
                                        role="checkbox"
                                        tabIndex={-1}
                                        key={i}
                                        onClick={() => {console.log(row)}}
                                    >

                                      <TableCell className="body-cell">
                                        {row.indexedBy.ssn[0]}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.indexedBy.planId[0]}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.indexedBy.accountNumber[0]}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.indexedBy.alphaCode[0]}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.workType}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.assignee}
                                      </TableCell>

                                      <TableCell className="body-cell">
                                        {row.dateTime}
                                      </TableCell>
                                    </TableRow>
                                );
                              })}
                        </TableBody>
                      </Table>
                      <TablePagination
                          rowsPerPageOptions={[5, 10, 25, 100]}
                          component="div"
                          count={this.state.resultsData.length}
                          rowsPerPage={this.state.rowsPerPage}
                          page={this.state.page}
                          onChangePage={this.handleChangePage}
                          onChangeRowsPerPage={this.handleChangeRowsPerPage}
                      />
                    </Paper>
                  </div>
                </div> }
          </div>
    );
  }
}

const mapStateToProps = (state) => {
    return {
        results: state.searchResults
    };
};
const mapDispatchToProps = dispatch => {
    return {
        search:object => dispatch(searchResults(object))
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(SearchResult);
