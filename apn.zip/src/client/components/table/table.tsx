import React from "react";
import "./table.scss";
import {Table, TableBody, TableHead,TableRow, TableCell, TablePagination, Paper } from "@material-ui/core";

const columns = [
    { id: 'name', label: 'Assignee', minWidth: 170 },
    { id: 'code', label: 'Indexed By', minWidth: 100 },
    {
        id: 'population',
        label: 'Plan Name',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    },
    {
        id: 'size',
        label: 'Service Type',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    },
    {
        id: 'subject',
        label: 'Subject',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    },
    {
        id: 'date',
        label: 'Date',
        minWidth: 170,
        align: 'right',
        format: (value: any) => value.toLocaleString('en-US'),
    }
];
const rows = [
    createData('BR01QM', 'BRK40502', '21st Century Scientific Inc', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'CBRK40502A', '21st Century Scientific Inc', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '21st Century Scientific Inc', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '21st Century Scientific Inc', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '21st Century Scientific Inc', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '198 East  Savings Plan', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17'),
    createData('BR01QM', 'BRK40502', '176 East LLC Employees', 'Lorem Impum dolor', 'Subject', '07/05/2020 12:06:17')
];
function createData(name, code, population, size, subject, date) {
    const density = population / size;
    return { name, code, population, size, subject, date };
}

interface TableState {
    showPopup: boolean;
    page: number;
    rowsPerPage: number;
}

class DataTable extends React.Component<{}, TableState> {
    state = {
        showPopup: false,
        page: 0,
        rowsPerPage: 5,
    };

    handleChangePage = (event, newPage) => {
        this.setState({ page: newPage })
    }

    handleChangeRowsPerPage = (event) => {
        this.setState({ page: 0, rowsPerPage: event.target.value })
    }

    render() {
        let { page, rowsPerPage } = this.state;
        return (
            <div className="table-component">
                <div className='table-wrapper'>
                    <Paper>
                        <Table stickyHeader aria-label="sticky table" className="table">
                            <TableHead className="table-head" >
                                <TableRow >
                                    {columns.map((column) => (
                                        <TableCell
                                            key={column.id}
                                            align={'left'}
                                            style={{ minWidth: column.minWidth }} >
                                            {column.label}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody className="table-body">
                                {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                                    return (
                                        <TableRow className="body-row" hover role="checkbox" tabIndex={-1} key={row.code}>
                                            {columns.map((column) => {
                                                const value = row[column.id];
                                                return (
                                                    <TableCell className="body-cell" key={column.id}>
                                                        {column.format && typeof value === 'number' ? column.format(value) : value}
                                                    </TableCell>
                                                );
                                            })}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25, 100]}
                            component="table"
                            count={rows.length}
                            rowsPerPage={this.state.rowsPerPage}
                            page={this.state.page}
                            onChangePage={this.handleChangePage}
                            onChangeRowsPerPage={this.handleChangeRowsPerPage} />
                    </Paper>
                </div>
            </div>
        );
    }
}

export default DataTable;