import React from "react";
import { shallow, configure } from "enzyme";
import { DataGrid } from "client/models";
import HistoryTable from "./history-table";
import Adapter from "enzyme-adapter-react-16";

let props: any;
let shippedNotice: DataGrid;
let cancelledNotice: DataGrid;
let pendingNotice: DataGrid;
let notDeliveredNotice: DataGrid;

configure({ adapter: new Adapter() });

describe("DataGrid History Table test", () => {
    beforeEach(() => {
        shippedNotice = new DataGrid();
        shippedNotice.status = "SENT";
        shippedNotice.shippingDate = "2019-12-06T15:39:46.58";
        cancelledNotice = new DataGrid();
        cancelledNotice.status = "CANCELED";
        pendingNotice = new DataGrid();
        pendingNotice.status = "PENDING";
        notDeliveredNotice = new DataGrid();
        notDeliveredNotice.status = "NOT DELIVERED";
        props = {
            notices: [shippedNotice, cancelledNotice, pendingNotice, notDeliveredNotice]
        };
    });

    it("should return shipped notice status date", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        expect(wrapper.instance().getStatusDate(shippedNotice)).toEqual("12 / 06 / 2019");
    });

    it("should return empty cancelled notice status date", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        expect(wrapper.instance().getStatusDate(cancelledNotice)).toEqual("");
    });

    it("should return empty pending notice status date", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        expect(wrapper.instance().getStatusDate(pendingNotice)).toEqual("");
    });

    it("should return empty not delivered notice status date", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        expect(wrapper.instance().getStatusDate(notDeliveredNotice)).toEqual("");
    });

    it("should show description expand icon", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        const description = "AasdfasdfasdfasdflajsdfasdfasdfaAasdfasdfasdfasdflajsdfasdfasdfaAasdfasdfasdfasdflajsdfasdfasdfaAasdfasdfasdfasdflajsdfasdfasdfaAasdfasdfasdfasdflajsdfasdfasdfa";
        expect(wrapper.instance().showExpandIcon(description)).toEqual(true);
    });

    it("should hide description expand icon with empty description", () => {
        const wrapper = shallow<HistoryTable>(<HistoryTable {...props} />);
        expect(wrapper.instance().showExpandIcon("")).toEqual(false);
    });
});