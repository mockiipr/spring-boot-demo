import React, { ReactNode } from "react";
import "./history-table.scss";
import { DataGrid } from "client/models";
import { Table, TableBody, TableHead, TableRow, TableCell, TableSortLabel } from "@material-ui/core";
import { ExpandLess, ExpandMore } from "@material-ui/icons";
import {
    Order,
    ascendingOrder, descendingOrder, stableSort, getSorting
} from "client/services/Utils";

import classNames from "classnames";

interface HistoryTableProps {
    notices: DataGrid[];
}

interface HistoryTableState {
    showPopup: boolean;
    notice: DataGrid;
    order: Order;
    orderBy: keyof DataGrid;
    expanded: boolean[];
}

interface HeadCell {
    id: keyof DataGrid;
    label: string;
    numeric: boolean;
    sortable: boolean;
}

const headCells: HeadCell[] = [
    { id: 'assignee', numeric: false, label: 'Assignee', sortable: true },
    { id: 'indexedBy', numeric: true, label: 'Indexed By', sortable: true },
    { id: 'planName', numeric: false, label: 'Plan Name', sortable: true },
    { id: 'serviceType', numeric: false, label: 'Service Type', sortable: true },
    { id: 'subject', numeric: true, label: 'Subject Line', sortable: true },
    { id: 'dateUpload', numeric: false, label: 'Date/Time', sortable: true },
];

const dateUploadKey: keyof DataGrid = "dateUpload";

class HistoryTable extends React.Component<HistoryTableProps, HistoryTableState> {
    state = {
        showPopup: false,
        notice: new DataGrid(),
        order: descendingOrder,
        orderBy: dateUploadKey,
        expanded: new Array(this.props.notices.length).fill(false)
    };

    getStatusDate(notice: DataGrid): string {
        let date = "";
        switch (notice.status) {
            case "SENT":
                date = notice.dateUpload;
                break;
            default:
                break;
        }
        return date;
    }

    onColumnSort(headCell: HeadCell) {
        const { order, orderBy } = this.state;
        const isAsc = orderBy === headCell.id && order === ascendingOrder;
        this.setState({
            order: isAsc ? descendingOrder : ascendingOrder,
            orderBy: headCell.id
        })
    }

    onConfirmationLinkClick(notice: DataGrid) {
        this.setState({
            showPopup: true,
            notice: notice
        });
    }

    onConfirmationClose() {
        this.setState({ showPopup: false });
    }

    onDescriptionExpanded(index: number) {
        let expanded: boolean[] = [...this.state.expanded];
        expanded[index] = true;
        this.setState({ expanded });
    }

    onDescriptionCollapsed(index: number) {
        let expanded: boolean[] = [...this.state.expanded];
        expanded[index] = false;
        this.setState({ expanded });
    }

    showExpandIcon(description: string): boolean {
        if (!description) {
            return false;
        }
        return description.length > 120;
    }

    renderContent(description: string, index: number): ReactNode | void {
        const { expanded } = this.state;
        if (this.showExpandIcon(description)) {
            return (
                <div className="expand-icons">
                    {
                        expanded[index]
                            ? <ExpandLess className="expand-less" onClick={() => this.onDescriptionCollapsed(index)} />
                            : <ExpandMore className="expand-more" onClick={() => this.onDescriptionExpanded(index)} />
                    }
                </div>
            )
        } else {
            return;
        }
    }

    render() {
        const { notices } = this.props;
        const { showPopup, notice, order, orderBy, expanded } = this.state;

        return (
            <div className="history-table-component">
                <div className='history-table-wrapper'>
                    <Table className="table">
                        <TableHead className="table-head">
                            <TableRow className="header-row MuiPaper-root MuiPaper-elevation1">
                                {headCells.map(headCell => (
                                    <TableCell className={classNames({
                                        "header-cell": true,
                                        "submitted": headCell.id === "dateUpload",
                                        //  "description": headCell.id === "description"
                                    })} sortDirection={orderBy === headCell.id ? order : false}>
                                        <TableSortLabel
                                            active={headCell.id === orderBy}
                                            direction={headCell.id === orderBy ? order : ascendingOrder}
                                            hideSortIcon={!headCell.sortable}
                                            onClick={() => {
                                                if (headCell.sortable) {
                                                    this.onColumnSort(headCell)
                                                }
                                            }} >
                                            {headCell.label}
                                        </TableSortLabel>
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody className="table-body">
                            {stableSort<DataGrid>(notices, getSorting<DataGrid>(order, orderBy))
                                .map((notice, index) => (
                                    <TableRow className="body-row" key={notice.assignee}>
                                        <TableCell className="body-cell submitted">
                                            <div className="year">{notice.dateUpload}</div>

                                        </TableCell>
                                        {/* <TableCell className="body-cell confirmation" onClick={() => this.onConfirmationLinkClick(notice)}>
                                            {notice.transactionId}</TableCell> */}
                                        <TableCell className={classNames({
                                            "body-cell": true,
                                            "status": true,
                                            "pending": notice.status === "PENDING",
                                            "sent": notice.status === "SENT",
                                            "cancelled": notice.status === "CANCELED",
                                            "not-delivered": notice.status === "NOT DELIVERED"
                                        })}>
                                            <div className="status-date">
                                                <div className="status">{notice.indexedBy}</div>
                                                {/* <div className="date">{this.getStatusDate(notice)}</div> */}
                                            </div>
                                        </TableCell>
                                        <TableCell className="body-cell">
                                            <div className={classNames({ "panel": true, "panel-expandable": this.showExpandIcon(notice.planName), "panel-expanded": expanded[index] })}>
                                                <div className={classNames({
                                                    "preview": !expanded[index],
                                                    "view": expanded[index]
                                                })}>
                                                    {notice.serviceType}
                                                </div>

                                            </div>
                                        </TableCell>
                                        <TableCell className="body-cell">{notice.subject}</TableCell>
                                        <TableCell className="body-cell username">{notice.dateUpload}</TableCell>
                                    </TableRow>
                                ))}
                        </TableBody>
                    </Table>
                </div>
                {/* {showPopup && (
                    <Confirmation
                        open={showPopup}
                        onClose={() => this.onConfirmationClose()}
                        notice={notice}
                        showConfirmation={false}
                    />
                )} */}
            </div>
        );
    }
}

export default HistoryTable;