import React from 'react';
import './mainComponent.scss';
import { ErrorHandler, TabComponent } from 'client/components'
import { WorkItemModal } from "client/components"

class MainComponent extends React.Component {
    onConfirmationClose() {
        this.setState({ showPopup: false });
    }
    render() {
        return (
            <ErrorHandler>
                <div>
                    <TabComponent />
                </div>
                <WorkItemModal openModal={false} onClose={() => this.onConfirmationClose()} />
            </ErrorHandler>
        )
    }
}

// const mapStateToProps = (state) => {
//     return {
//     };
// };
// const mapDispatchToProps = (state) => {
//     return {
//     };
// };
export default MainComponent
// connect(
//     mapStateToProps,
//     mapDispatchToProps
// )(MainComponent);