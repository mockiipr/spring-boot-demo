import React, { ReactNode } from "react";
import "./TableGrid.scss";
import { DataGrid } from "client/models";
import Logging from "client/services/client-logging";
import {
    Table,
    TableBody,
    TableHead,
    TableRow,
    TableCell,
    TableSortLabel,
    TablePagination,
    Snackbar,
    Tooltip,
    Paper,
    Grid,
    Divider,
    Select,
    MenuItem,
    FormControl,
    InputLabel
} from "@material-ui/core";

import {
    Order,
    ascendingOrder,
    descendingOrder,
    stableSort,
    getSorting
} from "client/services/Utils";

import classNames from "classnames";

interface DataGridProps {
    notices: DataGrid[];
}

interface DataGridState {
    showPopup: boolean;
    dataArray: DataGrid;
    order: Order;
    orderBy: keyof DataGrid;
    expanded: boolean[];
    page: number,
    rowsPerPage: number,
    micdValue: any
}

interface HeadCell {
    id: keyof DataGrid;
    label: string;
    numeric: boolean;
    sortable: boolean;
}

const headCells: HeadCell[] = [
    { id: 'assignee', numeric: false, label: 'Assignee', sortable: true },
    { id: 'indexedBy', numeric: true, label: 'Indexed By', sortable: true },
    { id: 'planName', numeric: false, label: 'Plan Name', sortable: true },
    { id: 'serviceType', numeric: false, label: 'Service Type', sortable: true },
    { id: 'subject', numeric: true, label: 'Subject Line', sortable: true },
    { id: 'dateUpload', numeric: false, label: 'Date/Time', sortable: true },
];

const dateTimeKey: keyof DataGrid = "dateUpload";

class TableGrid extends React.Component<DataGridProps, DataGridState> {
    state = {
        showPopup: false,
        dataArray: new DataGrid(),
        order: descendingOrder,
        orderBy: dateTimeKey,
        expanded: new Array(this.props.notices.length).fill(false),
        page: 0,
        rowsPerPage: 10,
        micdValue: ''
    };
    logging = new Logging();
    getStatusDate(notice: DataGrid): string {
        let date = "";
        switch (notice.status) {
            case "SENT":
                date = notice.dateUpload;
                break;
            default:
                break;
        }
        return date;
    }

    onColumnSort(headCell: HeadCell) {
        const { order, orderBy } = this.state;
        const isAsc = orderBy === headCell.id && order === ascendingOrder;
        this.setState({
            order: isAsc ? descendingOrder : ascendingOrder,
            orderBy: headCell.id
        })
    }

    onLinkClick(dataArray: DataGrid) {
        this.setState({
            showPopup: true,
            dataArray: dataArray
        });
    }

    onClose() {
        this.setState({ showPopup: false });
    }


    handleChangePage = (event, newPage) => {
        this.setState({ page: newPage })
    }

    handleChangeRowsPerPage = (event) => {
        this.setState({ page: 0, rowsPerPage: event.target.value })
    }
    handleChange = (event) => {
        this.setState({ micdValue: event.target.value })
      //  this.props.onClose();
    }
    render() {
        const { notices } = this.props;
        const { showPopup, page, order, orderBy, rowsPerPage } = this.state;
        this.logging.info('Table Grid renderd');
        return (
            <div className="data-table-component" id="TableGrid">
                <div className='data-table-wrapper' id="TableGrid-wrapper">
                    <Paper>
                        <div>
                            <Grid container alignItems="center" className='root'>
                                <span className="red-rect"></span> <span>Overdue 2</span>
                                <span className="blue-rect"></span><span>In Progress 4</span>
                                <Divider orientation="vertical" flexItem />
                                <span>11 Results</span>
                                <span>Show</span>
                                <FormControl variant="filled" >
                                    <InputLabel id="demo-simple-select-filled-label">Agdde</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-filled-label"
                                        id="demo-simple-select-filled"
                                        value={1}
                                        onChange={e => this.handleChange(e)}
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value={10}>Ten</MenuItem>
                                        <MenuItem value={20}>Twenty</MenuItem>
                                        <MenuItem value={30}>Thirty</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            {/* <span></span> */}

                        </div>
                        <Table className="table" id="TableGrid-component">
                            <TableHead className="table-head" id="TableHead-TableGrid-component">
                                <TableRow className="header-row MuiPaper-root MuiPaper-elevation1">
                                    {headCells.map(headCell => (
                                        <TableCell key={headCell.id} className={classNames({
                                            "header-cell": true,
                                            "submitted": headCell.id === "dateUpload",
                                            //  "description": headCell.id === "description"
                                        })} sortDirection={orderBy === headCell.id ? order : false}>
                                            <TableSortLabel
                                                active={headCell.id === orderBy}
                                                direction={headCell.id === orderBy ? order : ascendingOrder}
                                                hideSortIcon={!headCell.sortable}
                                                onClick={() => {
                                                    if (headCell.sortable) {
                                                        this.onColumnSort(headCell)
                                                    }
                                                }} >
                                                {headCell.label}
                                            </TableSortLabel>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody className="table-body">
                                {stableSort<DataGrid>(notices.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage), getSorting<DataGrid>(order, orderBy))
                                    .map((dataItem, index) => (
                                        <TableRow key={index} className={classNames({
                                            "body-row": true,
                                            "neutral-black-row": dataItem.assignee === "BR03WQ"
                                        })}>
                                            <TableCell onClick={() => this.onLinkClick(dataItem)}
                                                // className="body-cell submitted"
                                                className={classNames({
                                                    "body-cell submitted": true,
                                                    "red-left-border": dataItem.assignee === "BR01WQ",
                                                    "blue-left-border": dataItem.assignee === "BR03WQ1"
                                                    //  "description": headCell.id === "description"
                                                })}>
                                                <div className="year">{dataItem.assignee}</div>
                                            </TableCell>
                                            {/* <TableCell className="body-cell confirmation" onClick={() => this.onConfirmationLinkClick(dataItem)}>
                                            {dataItem.transactionId}</TableCell> */}
                                            <TableCell className={classNames({
                                                "body-cell": true,
                                                "status": true,
                                                "pending": dataItem.status === "PENDING",
                                                "sent": dataItem.status === "SENT",
                                                "cancelled": dataItem.status === "CANCELED",
                                                "not-delivered": dataItem.status === "NOT DELIVERED"
                                            })}>
                                                <div className="status-date">
                                                    <div className="status">{dataItem.indexedBy}</div>
                                                </div>
                                            </TableCell>
                                            <TableCell className="body-cell">
                                                <div className={classNames({ "panel": true })}>
                                                    <div>
                                                        {dataItem.planName}
                                                    </div>
                                                </div>
                                            </TableCell>

                                            <TableCell className="body-cell username">{dataItem.serviceType}</TableCell>
                                            <TableCell className="body-cell subject">
                                                <Tooltip title={dataItem.subject}>
                                                    <div className="text-wrap">{dataItem.subject}</div>
                                                </Tooltip>
                                            </TableCell>
                                            <TableCell className="body-cell username">
                                                {dataItem.dateUpload}
                                                <img className='refresh' alt="" src={require('client/assets/images/assignment-ind-24-px.png')} />
                                            </TableCell>
                                        </TableRow>
                                    ))}
                            </TableBody>
                        </Table>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25, 100]}
                            component="table"
                            style={{ display: "flex", flexDirection: "row-reverse" }}
                            count={this.props.notices.length}
                            colSpan={3}
                            rowsPerPage={this.state.rowsPerPage}
                            page={this.state.page}
                            onChangePage={this.handleChangePage}
                            onChangeRowsPerPage={this.handleChangeRowsPerPage} />

                    </Paper>
                </div>
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={showPopup}
                    onClose={() => this.onClose()}
                    message="Workitem successfully moved."
                    key={'vertical + horizontal'}
                />
                {/* {showPopup && (
                    <Confirmation
                        open={showPopup}
                        onClose={() => this.onConfirmationClose()}
                        notice={notice}
                        showConfirmation={false}
                    />
                )} */}
            </div >
        );
    }
}

export default TableGrid;