import * as React from "react";
import "./tooltip.scss";

export interface TooltipProps {
  message: string;
  closePopup?: () => void;
}
export default class Tooltip extends React.Component<TooltipProps> {
  state = {
    displayTooltip: false
  };

  hideTooltip() {
    this.setState({ displayTooltip: false });
  }
  componentDidMount() {
    document.body.addEventListener("click", e => this.handleBodyClick(e));
  }

  handleBodyClick(e: any) {
    if (
      e.target.className === "popoverBtn" ||
      e.target.className !== "tooltip-message"
    )
      this.setState({ displayTooltip: false });
  }
  showTooltip() {
    this.setState({ displayTooltip: true });
  }
  render() {
    let { message } = this.props;
    return (
      <span className="tooltip-container">
        {this.state.displayTooltip && (
          <div className={`tooltip-bubble tooltip-bottom tooltip-body`}>
            <div className="btn-container">
              <span className="close-btn" onClick={() => this.hideTooltip()} />
            </div>
            <div className="tooltip-message">{message}</div>
          </div>
        )}
        <span className="tooltip-trigger" onClick={() => this.showTooltip()}>
          {this.props.children}
        </span>
      </span>
    );
  }
}
