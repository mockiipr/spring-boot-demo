import * as React from "react";
import * as ReactDOM from "react-dom";
import Tooltip from './tooltip';
import { mount, configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

configure({ adapter: new Adapter() });

describe('components --> tooltip', () => {
    it('renders popup without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<Tooltip message={'This is a tooltip'} />, div);
    });
    it('calls render', () => {
        const spy = jest.spyOn(Tooltip.prototype, 'render');
        const wrapper = mount(<Tooltip message={'This is a tooltip'} />);
        expect(spy).toHaveBeenCalled();
        spy.mockReset();
        spy.mockRestore();
    });
});