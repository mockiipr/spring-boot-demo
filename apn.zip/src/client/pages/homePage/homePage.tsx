import React from 'react';
import './homePage.scss';

class HomePage extends React.Component {
    render() {
        return (
            <div>
                <table id="homePage" className="HomeMenuTable">
                    <tbody>
                        <tr>
                            <td className="HomeMenuHeaderbarNew" valign="middle">Search and Manage</td>
                        </tr>
                        <tr>
                            <td className="HomeIconCellNew"><a href="/allplansearch">
                            </a> Search All Plans</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }
}
export default HomePage;